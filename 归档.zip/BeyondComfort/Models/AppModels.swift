import Foundation

struct AccountUser: Codable, Equatable {
    let id: String
    let username: String
    let consentVersion: String
    let consentedAt: Date
}

/// Server-authoritative study availability. The app uses it only to construct a local session;
/// it never infers a condition from completion history or chooses a version itself.
struct StudyAccess: Codable, Equatable {
    let status: String
    let isAvailable: Bool
    let sequence: StudySequence?
    let period: Int?
    let condition: ExperimentalCondition?
    let availableAt: Date?
}

struct StudyParticipant: Codable, Identifiable, Equatable {
    let id: String
    let username: String
}

struct StudySchedule: Codable, Identifiable, Equatable {
    let userId: String
    let username: String
    let sequence: StudySequence?
    let periodOneStartsAt: Date?
    let periodTwoStartsAt: Date?
    let enabled: Bool

    var id: String { userId }
}

struct StudyScheduleUpdate: Encodable {
    let sequence: StudySequence
    let periodOneStartsAt: Date?
    let periodTwoStartsAt: Date?
    let enabled: Bool
}

struct RemoteSessionSummary: Codable, Identifiable {
    let id: String
    let stage: String
    let createdAt: Date
    let updatedAt: Date
    let payload: [String: JSONValue]
}

struct ResumableReflection: Identifiable {
    let id: String
    let remoteID: String?
    let session: ReflectionSession
    let updatedAt: Date
}

enum JSONValue: Codable {
    case string(String), number(Double), bool(Bool), object([String: JSONValue]), array([JSONValue]), null

    init(from decoder: Decoder) throws {
        let box = try decoder.singleValueContainer()
        if box.decodeNil() { self = .null }
        else if let value = try? box.decode(Bool.self) { self = .bool(value) }
        else if let value = try? box.decode(Double.self) { self = .number(value) }
        else if let value = try? box.decode(String.self) { self = .string(value) }
        else if let value = try? box.decode([String: JSONValue].self) { self = .object(value) }
        else { self = .array(try box.decode([JSONValue].self)) }
    }

    func encode(to encoder: Encoder) throws {
        var box = encoder.singleValueContainer()
        switch self {
        case .string(let value): try box.encode(value)
        case .number(let value): try box.encode(value)
        case .bool(let value): try box.encode(value)
        case .object(let value): try box.encode(value)
        case .array(let value): try box.encode(value)
        case .null: try box.encodeNil()
        }
    }
}

enum ReflectionState: String, Codable, CaseIterable, Sendable {
    case welcome
    case eventDisclosure
    case emotionDisclosure
    case bodilyResponse
    case selfJudgment
    case contextDisclosure
    case trackingPermission
    case trackingReview
    case tenderGrounding
    case readinessCheck
    case tenderExploration
    case cardIntroduction
    case cardInterpretation
    case attributionReflection
    case actionSelection
    case summary
    case completed
    case safetySupport

    init(from decoder: Decoder) throws {
        let value = try decoder.singleValueContainer().decode(String.self)
        if let state = Self(rawValue: value) {
            self = state
            return
        }
        // Migrate locally/cloud-persisted sessions from the earlier prototype state names.
        switch value {
        case "orient": self = .welcome
        case "contextGathering": self = .eventDisclosure
        case "contextConfirmation": self = .trackingPermission
        case "tenderGrounding": self = .tenderGrounding
        case "cardDraw": self = .cardIntroduction
        case "cardInterpretation": self = .cardInterpretation
        case "tenderExploration": self = .tenderExploration
        case "candidInquiry": self = .attributionReflection
        case "affirmationReadiness": self = .readinessCheck
        case "actionComposer": self = .actionSelection
        case "reviewClose": self = .summary
        case "safetyInterrupt": self = .safetySupport
        default: self = .welcome
        }
    }
}

typealias ReflectionStage = ReflectionState

/// Version 2 conversations deliberately keep only study-protocol boundaries in Swift. The LLM
/// decides the semantic purpose of each ordinary turn; this enum controls only which protocol
/// boundary and local capabilities are currently available.
enum ReflectionProtocolStage: String, Codable, CaseIterable, Sendable {
    case contextualDisclosure
    case tenderConfirmation
    case cardConsent
    case cardReflection
    case directReflection
    case narrativeConfirmation
    case optionalAction
    case complete
    case safetySupport
}

/// Coarse readiness is an application-owned progress lock, not a psychological judgment. The LLM
/// requests the transition by selecting a Tender/Fierce/final-narrative intent; Swift persists it
/// so a formatting repair cannot send an already-ready conversation back into more questioning.
enum ReflectionReadiness: String, Codable, Sendable {
    case needsTender
    case needsFierce
    case narrativeReady
}

enum TurnLocalActionKind: String, Codable, CaseIterable, Sendable {
    case none
    /// Marks a context-sized bundle of cleaned, application-supplied observations as presented.
    /// The planner may select one or several complementary observations from the bounded
    /// candidates Swift supplied; it never receives raw HealthKit or EventKit records.
    case presentTrackingCue
    /// Requests the application-owned uniform random draw. The model cannot provide a card ID.
    case drawRandomCard
    /// After the person has described an image relationship and connected it with a real
    /// relationship, authorizes the fixed local card guidance for a tentative, correctable
    /// reading. The catalogue remains hidden from the UI.
    case shareCardGuidance
    case completeSession
}

struct TurnLocalActionRequest: Codable, Equatable, Sendable {
    var kind: TurnLocalActionKind = .none
    var trackingCueIDs: [String] = []

    static let none = TurnLocalActionRequest()
}

enum TurnTrackingRelevance: String, Codable, CaseIterable, Sendable {
    case related, partlyRelated, unrelated, uncertain
}

enum TurnPracticeKind: String, Codable, CaseIterable, Sendable {
    case care
    case repair
    case protect
    case change
    case noAction
}

/// One complete assistant-authored practice the person can select, revise, or decline.
/// `noAction` remains a separate typed outcome and is never represented as a selectable option.
struct TurnPracticeOption: Codable, Equatable, Identifiable, Sendable {
    let id: String
    let kind: TurnPracticeKind
    let title: String
    let instruction: String
    let rationale: String
}

/// `noAction` is an evidence-bounded practice outcome, not a convenient way for the Planner to
/// skip proposing support. Swift validates this closed reason code while the semantic Critic
/// checks whether the conversation actually supports it.
enum TurnNoActionReason: String, Codable, CaseIterable, Sendable {
    case userDeclined
    case userNotReady
    case insufficientSupportedMaterial
}

/// The protocol-visible purpose of one assistant reply. Unlike the free-form writer guidance,
/// this value is deliberately small and closed so Swift can prevent a later workflow function
/// (for example practice or completion) from leaking into an earlier stage.
enum TurnReplyIntent: String, Codable, CaseIterable, Sendable {
    case exploreContext
    case presentTrackingContext
    case checkTrackingRelationship
    /// Records the person's assessment of already presented tracking cues and, in the same
    /// visible turn, presents a newly integrated Tender summary for its own confirmation.
    case integrateTrackingAndPresentTenderSummary
    case presentTenderSummary
    case requestTenderConfirmation
    case reviseTenderSummary
    case inviteCardConsent
    case acknowledgeCardConsent
    case acknowledgeCardDecline
    case inviteCardObservation
    case developCardImage
    case inviteCardConnection
    case authorizeCardGuidance
    case presentCardReading
    case directCandidReflection
    case presentFinalNarrative
    case requestNarrativeConfirmation
    case reviseFinalNarrative
    case suggestPractice
    case revisePractice
    case completeConversation
    case safetySupport
}

/// “Yes” is meaningful only in relation to the immediately pending confirmation. Keeping that
/// target typed prevents a tracking-related confirmation from being treated as acceptance of a
/// Tender summary, card mapping, final narrative, or practice.
enum TurnConfirmationTarget: String, Codable, CaseIterable, Sendable {
    case trackingRelationship
    case tenderSummary
    case cardConsent
    case cardMapping
    case finalNarrative
    case practice
}

/// What the latest user reply did to the confirmation request that was already visible. This is
/// deliberately separate from `TurnNextPrompt`, which describes what the new assistant reply will
/// ask next.
enum TurnConfirmationDecision: String, Codable, CaseIterable, Sendable {
    case related, partlyRelated, unrelated, uncertain
    case accepted, revised, rejected, unclear, declined
}

struct TurnResolvedConfirmation: Codable, Equatable, Sendable {
    let target: TurnConfirmationTarget
    let decision: TurnConfirmationDecision
    /// Opaque application-owned reference copied from the currently pending confirmation.
    /// Legacy sessions may have no reference ID, so this remains optional during migration.
    let referenceID: String?

    init(
        target: TurnConfirmationTarget,
        decision: TurnConfirmationDecision,
        referenceID: String? = nil
    ) {
        self.target = target
        self.decision = decision
        self.referenceID = referenceID
    }
}

enum TurnNextPromptKind: String, Codable, CaseIterable, Sendable {
    case none
    case openQuestion
    case confirmationRequest
}

/// The interaction the newly generated assistant reply establishes for the following user turn.
/// Swift validates only this structural contract; the LLM owns the semantic purpose and focus.
struct TurnNextPrompt: Codable, Equatable, Sendable {
    let kind: TurnNextPromptKind
    let purpose: String?
    let focus: String?
    let target: TurnConfirmationTarget?
    /// Assigned by Swift when a new confirmation request is committed. A Planner must copy the
    /// current value when resolving it, but does not invent an ID for a new prompt.
    let referenceID: String?

    static let none = TurnNextPrompt(
        kind: .none,
        purpose: nil,
        focus: nil,
        target: nil,
        referenceID: nil
    )

    static func openQuestion(purpose: String, focus: String) -> TurnNextPrompt {
        TurnNextPrompt(
            kind: .openQuestion,
            purpose: purpose,
            focus: focus,
            target: nil,
            referenceID: nil
        )
    }

    static func confirmationRequest(
        target: TurnConfirmationTarget,
        referenceID: String? = nil
    ) -> TurnNextPrompt {
        TurnNextPrompt(
            kind: .confirmationRequest,
            purpose: nil,
            focus: nil,
            target: target,
            referenceID: referenceID
        )
    }

    func assigningReferenceID(_ value: String) -> TurnNextPrompt {
        TurnNextPrompt(
            kind: kind,
            purpose: purpose,
            focus: focus,
            target: target,
            referenceID: value
        )
    }
}

struct TurnTrackingAssessment: Codable, Equatable, Sendable {
    let cueID: String
    let relevance: TurnTrackingRelevance
    /// This is the person's model-extracted interpretation, not a causal conclusion.
    let userInterpretation: String?
}

/// LLM-owned conversational memory. It records what has been understood and which question
/// functions have already been completed, while protocol state and local permissions remain
/// outside this structure.
struct TurnSemanticMemory: Codable, Equatable, Sendable {
    var situationUnderstanding = ""
    var answeredQuestionPurposes: [String] = []
    /// New protocol representation. Nil means an older saved session still relies on the legacy
    /// pending fields below; `.none` means the new protocol intentionally has no pending prompt.
    var nextPrompt: TurnNextPrompt?
    /// Legacy migration fields. New Planner responses do not write them.
    var pendingQuestionPurpose: String?
    var pendingConfirmationTarget: TurnConfirmationTarget?
    var trackingAssessments: [TurnTrackingAssessment] = []
    var tenderUnderstanding: String?
    var cardImageRelation: String?
    var cardRealityMapping: String?
    var cardNegotiatedMeaning: String?
    var fierceUnderstanding: String?
    var finalNarrative: String?
    /// Pending assistant-authored choices. Older sessions decode this additive field as `[]`.
    var practiceOptions: [TurnPracticeOption] = []
    var practiceKind: TurnPracticeKind?
    var selectedPractice: String?

    init(
        situationUnderstanding: String = "",
        answeredQuestionPurposes: [String] = [],
        nextPrompt: TurnNextPrompt? = nil,
        pendingQuestionPurpose: String? = nil,
        pendingConfirmationTarget: TurnConfirmationTarget? = nil,
        trackingAssessments: [TurnTrackingAssessment] = [],
        tenderUnderstanding: String? = nil,
        cardImageRelation: String? = nil,
        cardRealityMapping: String? = nil,
        cardNegotiatedMeaning: String? = nil,
        fierceUnderstanding: String? = nil,
        finalNarrative: String? = nil,
        practiceOptions: [TurnPracticeOption] = [],
        practiceKind: TurnPracticeKind? = nil,
        selectedPractice: String? = nil
    ) {
        self.situationUnderstanding = situationUnderstanding
        self.answeredQuestionPurposes = answeredQuestionPurposes
        self.nextPrompt = nextPrompt
        self.pendingQuestionPurpose = pendingQuestionPurpose
        self.pendingConfirmationTarget = pendingConfirmationTarget
        self.trackingAssessments = trackingAssessments
        self.tenderUnderstanding = tenderUnderstanding
        self.cardImageRelation = cardImageRelation
        self.cardRealityMapping = cardRealityMapping
        self.cardNegotiatedMeaning = cardNegotiatedMeaning
        self.fierceUnderstanding = fierceUnderstanding
        self.finalNarrative = finalNarrative
        self.practiceOptions = practiceOptions
        self.practiceKind = practiceKind
        self.selectedPractice = selectedPractice
    }

    private enum CodingKeys: String, CodingKey {
        case situationUnderstanding
        case answeredQuestionPurposes
        case nextPrompt
        case pendingQuestionPurpose
        case pendingConfirmationTarget
        case trackingAssessments
        case tenderUnderstanding
        case cardImageRelation
        case cardRealityMapping
        case cardNegotiatedMeaning
        case fierceUnderstanding
        case finalNarrative
        case practiceOptions
        case practiceKind
        case selectedPractice
    }

    init(from decoder: Decoder) throws {
        let box = try decoder.container(keyedBy: CodingKeys.self)
        situationUnderstanding =
            (try? box.decode(String.self, forKey: .situationUnderstanding)) ?? ""
        answeredQuestionPurposes =
            (try? box.decode([String].self, forKey: .answeredQuestionPurposes)) ?? []
        nextPrompt = try? box.decodeIfPresent(TurnNextPrompt.self, forKey: .nextPrompt)
        pendingQuestionPurpose =
            try? box.decodeIfPresent(String.self, forKey: .pendingQuestionPurpose)
        pendingConfirmationTarget =
            try? box.decodeIfPresent(
                TurnConfirmationTarget.self,
                forKey: .pendingConfirmationTarget
            )
        trackingAssessments =
            (try? box.decode([TurnTrackingAssessment].self, forKey: .trackingAssessments)) ?? []
        tenderUnderstanding =
            try? box.decodeIfPresent(String.self, forKey: .tenderUnderstanding)
        cardImageRelation =
            try? box.decodeIfPresent(String.self, forKey: .cardImageRelation)
        cardRealityMapping =
            try? box.decodeIfPresent(String.self, forKey: .cardRealityMapping)
        cardNegotiatedMeaning =
            try? box.decodeIfPresent(String.self, forKey: .cardNegotiatedMeaning)
        fierceUnderstanding =
            try? box.decodeIfPresent(String.self, forKey: .fierceUnderstanding)
        finalNarrative =
            try? box.decodeIfPresent(String.self, forKey: .finalNarrative)
        practiceOptions =
            (try? box.decode([TurnPracticeOption].self, forKey: .practiceOptions)) ?? []
        practiceKind =
            try? box.decodeIfPresent(TurnPracticeKind.self, forKey: .practiceKind)
        selectedPractice =
            try? box.decodeIfPresent(String.self, forKey: .selectedPractice)
    }

    /// New Planner requests use `nextPrompt` as their only pending-interaction source. The
    /// application still stores the legacy mirrors so an older saved session or local view can
    /// resume safely, but exposing both representations to the model can make it answer the same
    /// confirmation twice. Old sessions without `nextPrompt` keep their legacy migration data.
    func plannerFacingProjection() -> TurnSemanticMemory {
        guard nextPrompt != nil else { return self }
        var projected = self
        projected.pendingQuestionPurpose = nil
        projected.pendingConfirmationTarget = nil
        return projected
    }

    mutating func apply(
        _ update: TurnSemanticMemoryUpdate,
        committedNextPrompt: TurnNextPrompt? = nil
    ) {
        if let value = update.situationUnderstanding {
            situationUnderstanding = value
        }
        if let values = update.answeredQuestionPurposes {
            answeredQuestionPurposes = Array(
                Set(answeredQuestionPurposes + values)
            ).sorted()
        }
        if let committedNextPrompt {
            nextPrompt = committedNextPrompt
            // Mirror the new prompt into legacy fields so older local views and safely resumed
            // sessions continue to understand the pending interaction during migration.
            switch committedNextPrompt.kind {
            case .none:
                pendingQuestionPurpose = nil
                pendingConfirmationTarget = nil
            case .openQuestion:
                pendingQuestionPurpose = committedNextPrompt.purpose
                pendingConfirmationTarget = nil
            case .confirmationRequest:
                pendingQuestionPurpose = committedNextPrompt.target.map {
                    "confirm_\($0.rawValue)"
                }
                pendingConfirmationTarget = committedNextPrompt.target
            }
        } else {
            // Legacy Planner/session compatibility.
            if update.clearPendingQuestionPurpose == true {
                pendingQuestionPurpose = nil
                pendingConfirmationTarget = nil
            }
            if let value = update.pendingQuestionPurpose {
                pendingQuestionPurpose = value
            }
            if let value = update.pendingConfirmationTarget {
                pendingConfirmationTarget = value
            }
        }
        if let assessments = update.trackingAssessments {
            var indexed = Dictionary(uniqueKeysWithValues: trackingAssessments.map { ($0.cueID, $0) })
            assessments.forEach { indexed[$0.cueID] = $0 }
            trackingAssessments = indexed.values.sorted { $0.cueID < $1.cueID }
        }
        if let value = update.tenderUnderstanding { tenderUnderstanding = value }
        if let value = update.cardImageRelation { cardImageRelation = value }
        if let value = update.cardRealityMapping { cardRealityMapping = value }
        if let value = update.cardNegotiatedMeaning { cardNegotiatedMeaning = value }
        if let value = update.fierceUnderstanding { fierceUnderstanding = value }
        if let value = update.finalNarrative { finalNarrative = value }
        if let value = update.practiceOptions { practiceOptions = value }
        if let value = update.practiceKind { practiceKind = value }
        if let value = update.selectedPractice { selectedPractice = value }
    }
}

/// Optional patch fields let the controller update only the semantic relationship established by
/// the latest turn. Empty strings are meaningful corrections and therefore are not discarded.
struct TurnSemanticMemoryUpdate: Codable, Equatable, Sendable {
    var situationUnderstanding: String?
    var answeredQuestionPurposes: [String]?
    var pendingQuestionPurpose: String?
    var pendingConfirmationTarget: TurnConfirmationTarget?
    var clearPendingQuestionPurpose: Bool?
    var trackingAssessments: [TurnTrackingAssessment]?
    var tenderUnderstanding: String?
    var cardImageRelation: String?
    var cardRealityMapping: String?
    var cardNegotiatedMeaning: String?
    var fierceUnderstanding: String?
    var finalNarrative: String?
    var practiceOptions: [TurnPracticeOption]?
    var practiceKind: TurnPracticeKind?
    var selectedPractice: String?

    init(
        situationUnderstanding: String? = nil,
        answeredQuestionPurposes: [String]? = nil,
        pendingQuestionPurpose: String? = nil,
        pendingConfirmationTarget: TurnConfirmationTarget? = nil,
        clearPendingQuestionPurpose: Bool? = nil,
        trackingAssessments: [TurnTrackingAssessment]? = nil,
        tenderUnderstanding: String? = nil,
        cardImageRelation: String? = nil,
        cardRealityMapping: String? = nil,
        cardNegotiatedMeaning: String? = nil,
        fierceUnderstanding: String? = nil,
        finalNarrative: String? = nil,
        practiceOptions: [TurnPracticeOption]? = nil,
        practiceKind: TurnPracticeKind? = nil,
        selectedPractice: String? = nil
    ) {
        self.situationUnderstanding = situationUnderstanding
        self.answeredQuestionPurposes = answeredQuestionPurposes
        self.pendingQuestionPurpose = pendingQuestionPurpose
        self.pendingConfirmationTarget = pendingConfirmationTarget
        self.clearPendingQuestionPurpose = clearPendingQuestionPurpose
        self.trackingAssessments = trackingAssessments
        self.tenderUnderstanding = tenderUnderstanding
        self.cardImageRelation = cardImageRelation
        self.cardRealityMapping = cardRealityMapping
        self.cardNegotiatedMeaning = cardNegotiatedMeaning
        self.fierceUnderstanding = fierceUnderstanding
        self.finalNarrative = finalNarrative
        self.practiceOptions = practiceOptions
        self.practiceKind = practiceKind
        self.selectedPractice = selectedPractice
    }

    private enum CodingKeys: String, CodingKey {
        case situationUnderstanding
        case answeredQuestionPurposes
        case pendingQuestionPurpose
        case pendingConfirmationTarget
        case clearPendingQuestionPurpose
        case trackingAssessments
        case tenderUnderstanding
        case cardImageRelation
        case cardRealityMapping
        case cardNegotiatedMeaning
        case fierceUnderstanding
        case finalNarrative
        case practiceOptions
        case practiceKind
        case selectedPractice
    }

    init(from decoder: Decoder) throws {
        let box = try decoder.container(keyedBy: CodingKeys.self)
        // Semantic-memory fields are patches, not capability requests. A malformed optional patch
        // must not make an otherwise decodable Planner response disappear. Required narrative
        // content is still enforced later by the protocol controller for the intent that needs it.
        situationUnderstanding = try? box.decode(
            String.self,
            forKey: .situationUnderstanding
        )
        if let values = try? box.decode(
            [String].self,
            forKey: .answeredQuestionPurposes
        ) {
            answeredQuestionPurposes = values
        } else if let value = try? box.decode(
            String.self,
            forKey: .answeredQuestionPurposes
        ) {
            answeredQuestionPurposes = [value]
        } else {
            answeredQuestionPurposes = nil
        }
        pendingQuestionPurpose = try? box.decode(
            String.self,
            forKey: .pendingQuestionPurpose
        )
        pendingConfirmationTarget = try? box.decode(
            TurnConfirmationTarget.self,
            forKey: .pendingConfirmationTarget
        )
        clearPendingQuestionPurpose = try? Self.decodeOptionalProtocolBool(
            from: box,
            forKey: .clearPendingQuestionPurpose
        )
        trackingAssessments = try? box.decode(
            [TurnTrackingAssessment].self,
            forKey: .trackingAssessments
        )
        tenderUnderstanding = try? box.decode(
            String.self,
            forKey: .tenderUnderstanding
        )
        cardImageRelation = try? box.decode(
            String.self,
            forKey: .cardImageRelation
        )
        cardRealityMapping = try? box.decode(
            String.self,
            forKey: .cardRealityMapping
        )
        cardNegotiatedMeaning = try? box.decode(
            String.self,
            forKey: .cardNegotiatedMeaning
        )
        fierceUnderstanding = try? box.decode(
            String.self,
            forKey: .fierceUnderstanding
        )
        finalNarrative = try? box.decode(
            String.self,
            forKey: .finalNarrative
        )
        practiceOptions = try? box.decode(
            [TurnPracticeOption].self,
            forKey: .practiceOptions
        )
        if let rawPracticeKind = try? box.decode(
            String.self,
            forKey: .practiceKind
        ) {
            practiceKind = TurnPracticeKind(rawValue: rawPracticeKind)
        } else {
            practiceKind = nil
        }
        selectedPractice = try? box.decode(
            String.self,
            forKey: .selectedPractice
        )
    }

    private static func decodeOptionalProtocolBool(
        from box: KeyedDecodingContainer<CodingKeys>,
        forKey key: CodingKeys
    ) throws -> Bool? {
        guard box.contains(key), try !box.decodeNil(forKey: key) else { return nil }
        if let value = try? box.decode(Bool.self, forKey: key) {
            return value
        }
        if let raw = try? box.decode(String.self, forKey: key) {
            switch raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
            case "true":
                return true
            case "false":
                return false
            default:
                break
            }
        }
        throw DecodingError.typeMismatch(
            Bool.self,
            .init(
                codingPath: box.codingPath + [key],
                debugDescription: "Expected a JSON boolean, null, or the exact string true/false."
            )
        )
    }
}

/// The semantic planner can recommend protocol movement and describe the communicative purpose
/// of the next reply, but it does not write text shown to the person.
struct LLMTurnResponsePlan: Codable, Equatable, Sendable {
    let requestedStage: ReflectionProtocolStage
    let localAction: TurnLocalActionRequest
    let memoryUpdate: TurnSemanticMemoryUpdate
    /// Resolution of the prompt visible before this turn. Missing only for legacy responses.
    let resolvedConfirmation: TurnResolvedConfirmation?
    /// Prompt established by the new visible reply. Missing only for legacy responses.
    let nextPrompt: TurnNextPrompt?
    let replyIntent: TurnReplyIntent
    /// Required only when a proposed practice uses `practiceKind = noAction`.
    let noActionReason: TurnNoActionReason?
    /// Natural-language details grounded in the latest turn. This can describe what to acknowledge
    /// but cannot change the typed intent or authorize a workflow function.
    let replyGuidance: String

    init(
        requestedStage: ReflectionProtocolStage,
        localAction: TurnLocalActionRequest,
        memoryUpdate: TurnSemanticMemoryUpdate,
        resolvedConfirmation: TurnResolvedConfirmation? = nil,
        nextPrompt: TurnNextPrompt? = nil,
        replyIntent: TurnReplyIntent,
        noActionReason: TurnNoActionReason? = nil,
        replyGuidance: String
    ) {
        self.requestedStage = requestedStage
        self.localAction = localAction
        self.memoryUpdate = memoryUpdate
        self.resolvedConfirmation = resolvedConfirmation
        self.nextPrompt = nextPrompt
        self.replyIntent = replyIntent
        self.noActionReason = noActionReason
        self.replyGuidance = replyGuidance
    }
}

/// The Writer has one job: express an already planned turn naturally. It cannot request stages,
/// local capabilities, tracking access, or memory changes.
struct LLMTurnWriterResponse: Codable, Equatable, Sendable {
    let realizedIntent: TurnReplyIntent
    let reply: String
}

struct LLMTurnControllerResponse: Codable, Equatable, Sendable {
    let requestedStage: ReflectionProtocolStage
    let localAction: TurnLocalActionRequest
    let memoryUpdate: TurnSemanticMemoryUpdate
    let resolvedConfirmation: TurnResolvedConfirmation?
    let nextPrompt: TurnNextPrompt?
    let replyIntent: TurnReplyIntent
    let noActionReason: TurnNoActionReason?
    let reply: String

    init(
        requestedStage: ReflectionProtocolStage,
        localAction: TurnLocalActionRequest,
        memoryUpdate: TurnSemanticMemoryUpdate,
        resolvedConfirmation: TurnResolvedConfirmation? = nil,
        nextPrompt: TurnNextPrompt? = nil,
        replyIntent: TurnReplyIntent,
        noActionReason: TurnNoActionReason? = nil,
        reply: String
    ) {
        self.requestedStage = requestedStage
        self.localAction = localAction
        self.memoryUpdate = memoryUpdate
        self.resolvedConfirmation = resolvedConfirmation
        self.nextPrompt = nextPrompt
        self.replyIntent = replyIntent
        self.noActionReason = noActionReason
        self.reply = reply
    }
}

/// A persisted, research-facing workflow phase that is intentionally finer grained than the
/// legacy UI/LLM `ReflectionState`. Keeping the two separate lets Swift own the fixed study
/// sequence without exposing new internal route names in the interface or breaking older prompt
/// and view switches. New cases are additive and older sessions infer a safe phase from `stage`.
enum ReflectionWorkflowPhase: String, Codable, CaseIterable, Sendable {
    case opening
    case structuredDisclosure
    case tenderGroundingConfirmation
    case trackingReview
    /// After the person says the records resemble their recent state, ask once whether that
    /// state mattered in the concrete event. This keeps tracking from jumping directly to a
    /// synthesis or card invitation, while preserving "no effect" as a complete answer.
    case trackingContextLink
    case contextConfirmation
    case cardSelection
    case cardDisplay
    case cardObservation
    case cardAssociation
    /// Legacy resume-only phase retained for sessions saved before the normal card path was
    /// shortened to two image turns. New sessions use an image-only scaffold only after the
    /// first life-connection invitation proves difficult.
    case cardNarrativeDeepening
    case cardConnection
    /// The app presents one explicitly tentative mapping between a relationship the person
    /// described in the image and the already confirmed real situation. It may only be used
    /// later if the person accepts or revises it.
    case cardMappingConfirmation
    /// The user, not the model, says whether the card changed or sharpened how they understand
    /// the original situation after the concrete circumstances have been named and before agency.
    case cardMeaningShift
    case candidCircumstances
    case candidAgency
    case reflectionNarrativeConfirmation
    case optionalAction
    case actionConfirmation
    case narrativeConfirmation
    case complete
    case safetySupport
}

struct ReflectionWorkflowStateMachine {
    func canTransition(from: ReflectionWorkflowPhase, to: ReflectionWorkflowPhase) -> Bool {
        if to == .safetySupport { return from != .complete }
        if from == to { return true }
        let allowed: [ReflectionWorkflowPhase: Set<ReflectionWorkflowPhase>] = [
            .opening: [.structuredDisclosure],
            .structuredDisclosure: [.tenderGroundingConfirmation],
            .tenderGroundingConfirmation: [.trackingReview],
            .trackingReview: [.trackingContextLink, .contextConfirmation],
            .trackingContextLink: [.contextConfirmation],
            // A resumed direct-condition session may have an old confirmation but no completed
            // tracking review. It must return to the shared tracking gate before candid reflection.
            .contextConfirmation: [.cardSelection, .candidCircumstances, .trackingReview],
            .cardSelection: [.cardDisplay],
            .cardDisplay: [.cardSelection, .cardObservation],
            .cardObservation: [.cardAssociation, .candidCircumstances],
            // New reflections move from the second image turn directly to the first optional
            // life-connection invitation. `cardNarrativeDeepening` remains as a resume-only
            // legacy phase for sessions saved by earlier builds.
            .cardAssociation: [.cardConnection, .cardNarrativeDeepening, .candidCircumstances],
            .cardNarrativeDeepening: [.cardConnection, .candidCircumstances],
            // A card-to-life connection is only a bridge. Even when the person authors a complete
            // mapping themselves, the app first makes room for the real conditions around it.
            // Keeping this edge strict prevents restored sessions and fallback paths from
            // bypassing the Tender circumstances turn.
            .cardConnection: [.cardMappingConfirmation, .candidCircumstances],
            .cardMappingConfirmation: [.candidCircumstances],
            // The direct condition has no card meaning-shift turn, so it may enter a concrete
            // fierce question directly from circumstances. In either condition, when the user
            // has supplied no behaviour/consequence/boundary that warrants fierce compassion,
            // the app may retain tender understanding and continue to the narrative instead.
            .candidCircumstances: [.cardMeaningShift, .candidAgency, .reflectionNarrativeConfirmation],
            .cardMeaningShift: [.candidAgency, .reflectionNarrativeConfirmation],
            .candidAgency: [.reflectionNarrativeConfirmation],
            .reflectionNarrativeConfirmation: [.optionalAction],
            .optionalAction: [.actionConfirmation, .narrativeConfirmation],
            .actionConfirmation: [.narrativeConfirmation],
            // A person may ask for a practice after first choosing to keep only the narrative.
            // This late return is user-initiated; it does not reopen attribution or assign a
            // responsibility direction.
            .narrativeConfirmation: [.optionalAction, .complete],
            .complete: [],
            .safetySupport: [.complete],
        ]
        return allowed[from, default: []].contains(to)
    }
}

enum CompassionRoute: String, Codable, CaseIterable {
    case tenderStabilize, protect, provide, repair, change, explore
}

enum ConsentState: String, Codable { case unknown, yes, no }
enum ControllabilityLevel: String, Codable { case unknown, low, mixed, high }
enum AgencyLevel: String, Codable { case unknown, low, medium, high }

/// Private semantic candidates from the ContextAnalyzer. They describe the current disclosure,
/// never assign fault or advance the reflection workflow on their own.
enum ReflectionEventType: String, Codable {
    case taskProgress
    case criticism
    case interpersonalConflict
    case relationalHurt
    case failure
    case boundary
    case externalUnfairness
    case unclear
}

enum TaskProgressStatus: String, Codable {
    case notApplicable
    case unclear
    case notStarted
    case startedButStalled
    case activelyWorkingButIneffective
    case completedButDisappointed
}

enum ExperimentalCondition: String, Codable, CaseIterable {
    case cardMediated
    /// Retains the existing persisted/server value for backward-compatible research records.
    case directLLM = "modelAsserted"

    var usesCard: Bool { self == .cardMediated }
}

/// Counterbalanced order for the two-session crossover. Swift owns use of this value; the model
/// never receives it or decides a participant's condition.
enum StudySequence: String, Codable, CaseIterable {
    case cardFirst, directFirst

    func condition(for period: Int) -> ExperimentalCondition? {
        switch (self, period) {
        case (.cardFirst, 1), (.directFirst, 2): return .cardMediated
        case (.directFirst, 1), (.cardFirst, 2): return .directLLM
        default: return nil
        }
    }
}

enum MessageRole: String, Codable { case assistant, user, system }

struct ChatMessage: Identifiable, Codable, Equatable {
    let id: UUID
    let role: MessageRole
    var content: String
    let createdAt: Date
    let state: ReflectionState?
    /// Persisted turn linkage makes retries and resumed sessions idempotent: one typed user turn
    /// may own at most one visible assistant message.
    let replyToMessageID: UUID?
    let assistantGenerationID: UUID?

    init(
        id: UUID = UUID(),
        role: MessageRole,
        content: String,
        createdAt: Date = .now,
        state: ReflectionState? = nil,
        replyToMessageID: UUID? = nil,
        assistantGenerationID: UUID? = nil
    ) {
        self.id = id
        self.role = role
        self.content = content
        self.createdAt = createdAt
        self.state = state
        self.replyToMessageID = replyToMessageID
        self.assistantGenerationID = assistantGenerationID
    }
}

enum ReflectionDimension: String, Codable, CaseIterable {
    case event, emotion, body, selfJudgment, personalMeaning, context, uncertainty, agency, readiness, cardNarrative
}

enum QuestionGoal: String, Codable, CaseIterable {
    case specificEvent, emotionalMeaning, bodilyExperience, selfTalk, contextualPressure
    case uncertainty, pastChoice, presentAgency, preferredDirection
    /// `cardNarrative` is retained for previously saved sessions. New sessions distinguish the
    /// observable-picture turn from the dynamic-picture turn.
    case cardNarrative, cardObservation, cardDevelopment, cardConnection
    case trackingRelevance, trackingImpact, perspectiveShift, compassionateAction
}

/// One semantic purpose for the next visible response. The Analyzer proposes this plan from the
/// latest user turn; Swift validates its literal evidence and phase permissions before the Writer
/// can see it. These are dialogue functions, not topics, diagnoses, or workflow transitions.
enum ResponseFunction: String, Codable, CaseIterable, Sendable {
    case exploreLivedExperience
    case clarifyPersonalMeaning
    case clarifyCircumstances
    case synthesizeTenderUnderstanding
    case contextualizeTracking
    case developImageRelation
    case connectImageToReality
    case deepenTenderUnderstanding
    case explorePerspectiveShift
    case exploreAgencyBoundaryOrChange
    case synthesizeNarrative
    case proposePractice
    case confirmUnderstanding
    case closeWithoutQuestion
}

struct ResponsePlan: Codable, Equatable, Sendable {
    var function: ResponseFunction
    /// A compact semantic focus for the Writer. It is internal and must not be copied verbatim.
    var focus: String
    /// Short literal fragments copied from user messages. Swift verifies every fragment.
    var evidence: [String]
    /// Relation functions the plan claims to use. Swift requires locally grounded matches.
    var relationKinds: [SemanticRelationKind]
    /// What the one optional question should accomplish, not the wording of the question.
    var questionIntent: String
    var shouldAskQuestion: Bool
    var confidence: Double

    var validated: ResponsePlan {
        var copy = self
        copy.focus = String(focus.trimmingCharacters(in: .whitespacesAndNewlines).prefix(180))
        copy.evidence = Array(
            evidence
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty && $0.count <= 120 }
                .prefix(4)
        )
        copy.relationKinds = Array(Set(relationKinds).prefix(5))
        copy.questionIntent = String(
            questionIntent.trimmingCharacters(in: .whitespacesAndNewlines).prefix(220)
        )
        copy.confidence = min(max(confidence, 0), 1)
        return copy
    }
}

/// Swift supplies this boundary only for a turn whose wording needs to understand the latest
/// user message. It does not authorize a transition or expose internal workflow names to the UI.
/// Fixed system notices, safety handling, experimental-condition gates, tracking confirmation,
/// and state progression do not use this planning context.
struct ResponsePlanningContext: Codable, Equatable, Sendable {
    var state: ReflectionState
    var workflowPhase: ReflectionWorkflowPhase
    var allowedFunctions: [ResponseFunction]
    var shouldAskQuestion: Bool?

    var validated: ResponsePlanningContext {
        var copy = self
        copy.allowedFunctions = Array(Set(allowedFunctions)).sorted { $0.rawValue < $1.rawValue }
        return copy
    }
}

enum CardPreference: String, Codable {
    case available, deferred, declined, completed
}

enum CardDisplayState: String, Codable {
    case none, selected, displayed, loadFailed
}

struct DialogueProgress: Codable, Equatable {
    var currentState: ReflectionState = .welcome
    var completedDimensions: Set<ReflectionDimension> = []
    var unresolvedDimensions: Set<ReflectionDimension> = Set(ReflectionDimension.allCases)
    var recentQuestionGoals: [QuestionGoal] = []
    /// Optional for additive decoding of sessions saved before cumulative function tracking.
    var askedQuestionGoals: Set<QuestionGoal>?
    var lastAssistantQuestion: String?
    var nextQuestionGoal: QuestionGoal?
    var forbiddenNextGoals: Set<QuestionGoal> = []
    var cardPreference: CardPreference = .available
    var continueConversation = true

    mutating func record(questionGoal: QuestionGoal?, question: String?) {
        if let questionGoal {
            recentQuestionGoals.append(questionGoal)
            recentQuestionGoals = Array(recentQuestionGoals.suffix(3))
            var asked = askedQuestionGoals
                ?? forbiddenNextGoals.union(Set(recentQuestionGoals))
            asked.insert(questionGoal)
            askedQuestionGoals = asked
            forbiddenNextGoals = asked
            nextQuestionGoal = nil
        }
        if let question, !question.isEmpty { lastAssistantQuestion = question }
    }

    mutating func complete(_ dimension: ReflectionDimension) {
        completedDimensions.insert(dimension)
        unresolvedDimensions.remove(dimension)
    }
}

struct ContextCanvas: Codable, Equatable {
    var narrative = ""
    var eventDate = Date()
    var event = ""
    var experience = ""
    var meaning = ""
    var constraints = ""
    var agencyAndUncertainty = ""
    var reflectiveIntention = ""
    var contextualFactors = ""

    var reported: String {
        [narrative, event, experience, meaning, constraints, agencyAndUncertainty, reflectiveIntention]
            .filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .joined(separator: "\n")
    }

    var uncertainty: String { agencyAndUncertainty }
}

struct ReflectionContext: Codable, Equatable {
    var eventDescription: String?
    var eventDate = Date()
    var emotions: [String] = []
    var bodilyResponses: [String] = []
    var selfJudgment: String?
    /// User-authored personal meaning is separate from a global self-label so later summaries can
    /// keep the concern while translating identity judgments into situation-specific language.
    var personalMeaning: String?
    var contextualConstraints: [String] = []
    var personalContributions: [String] = []
    var uncertainties: [String] = []
    var pastControllability: ControllabilityLevel = .unknown
    var presentAgency: AgencyLevel = .unknown
    var possibleImpactOnOthers: [String] = []
    var possibleBoundaryConcerns: [String] = []
    var unmetNeeds: [String] = []
    var repeatingPatterns: [String] = []
    var confirmedTrackingCues: [TrackingCue] = []
    var rejectedTrackingCueIDs: Set<String> = []
    var confirmedTrackingInsights: [ConfirmedTrackingContext]?
    var selectedCardID: String?
    var cardInterpretation: String?
    var selectedAction: CompassionateAction?

    var narrativeSummary: String {
        var parts: [String] = []
        if let eventDescription, !eventDescription.isEmpty { parts.append(eventDescription) }
        if !emotions.isEmpty { parts.append("感受：" + emotions.joined(separator: "、")) }
        if !bodilyResponses.isEmpty { parts.append("身体反应：" + bodilyResponses.joined(separator: "、")) }
        if let selfJudgment, !selfJudgment.isEmpty { parts.append("当时对自己的判断：" + selfJudgment) }
        if let personalMeaning, !personalMeaning.isEmpty { parts.append("这件事对自己的意义：" + personalMeaning) }
        if !contextualConstraints.isEmpty { parts.append("情境限制：" + contextualConstraints.joined(separator: "、")) }
        if !uncertainties.isEmpty { parts.append("仍不确定：" + uncertainties.joined(separator: "、")) }
        return parts.joined(separator: "\n")
    }

    init() {}

    init(legacy: ContextCanvas) {
        eventDescription = legacy.event.isEmpty ? (legacy.narrative.isEmpty ? nil : legacy.narrative) : legacy.event
        eventDate = legacy.eventDate
        emotions = legacy.experience.isEmpty ? [] : [legacy.experience]
        bodilyResponses = []
        selfJudgment = legacy.meaning.isEmpty ? nil : legacy.meaning
        personalMeaning = nil
        contextualConstraints = legacy.constraints.isEmpty ? [] : [legacy.constraints]
        personalContributions = []
        uncertainties = legacy.agencyAndUncertainty.isEmpty ? [] : [legacy.agencyAndUncertainty]
        pastControllability = .unknown
        presentAgency = .unknown
        possibleImpactOnOthers = []
        possibleBoundaryConcerns = []
        unmetNeeds = legacy.reflectiveIntention.isEmpty ? [] : [legacy.reflectiveIntention]
        repeatingPatterns = []
        confirmedTrackingCues = []
        rejectedTrackingCueIDs = []
        cardInterpretation = nil
        selectedAction = nil
    }
}

enum TrackingSource: String, Codable {
    case healthSleep, healthHeartRate, healthHRV, healthSteps, calendarLoad
}

enum TrackingMetric: String, Codable, CaseIterable {
    case sleepDuration, sleepTiming, sleepWakeTime, sleepContinuity
    case restingHeartRate, heartRateVariability, steps
    case calendarLoad, screenTime, weather
}

enum TrackingInsightStrength: String, Codable {
    case descriptiveOnly, baselineComparison, persistentPattern
}

enum TrackingInsightConfidence: String, Codable {
    case low, moderate, high
}

struct TrackingProvenance: Codable, Equatable {
    var sampleType: String
    var sourceName: String?
    var sourceBundleIdentifier: String?
    var sourceVersion: String?
    var deviceName: String?
    var startDate: Date?
    var endDate: Date?
    var timeZoneIdentifier: String
    var sampleCount: Int
    var authorizationStatus: String
}

enum TrackingCueRelevance: String, Codable, CaseIterable {
    case notReviewed, relevant, irrelevant, uncertain
}

struct TrackingDataPoint: Identifiable, Codable, Equatable {
    let date: Date
    let value: Double?
    let count: Int

    var id: Date { date }
}

struct TrackingInsight: Identifiable, Codable, Equatable {
    let id: UUID
    let metric: TrackingMetric
    let observationWindow: DateInterval
    let validSampleCount: Int
    let expectedSampleCount: Int
    let coverageDescription: String
    let neutralObservation: String
    let baselineWindow: DateInterval?
    let baselineDescription: String?
    let absoluteDifference: Double?
    let relativeDifference: Double?
    let strength: TrackingInsightStrength
    let confidence: TrackingInsightConfidence
    let limitations: [String]
    let possibleConfounders: [String]
    let suggestedReflectionQuestion: String
    let provenance: [TrackingProvenance]
    let recentMedian: Double?
    let baselineMedian: Double?
    let medianAbsoluteDeviation: Double?
    let interquartileRange: Double?
    let longestConsecutiveRun: Int
    var userRelevance: TrackingCueRelevance
}

struct ConfirmedTrackingContext: Codable, Equatable {
    let insightID: UUID
    let observation: String
    let userInterpretation: String?
    let relevance: TrackingCueRelevance
}

struct PatternCandidate: Identifiable, Codable, Equatable {
    let id: UUID
    let observedFeatures: [String]
    let observationWindows: [DateInterval]
    let coverage: [String]
    let limitations: [String]
    let alternativeExplanations: [String]
    let suggestedReflectionQuestion: String
}

struct SelfTrackingDataset: Codable, Equatable {
    var dailyMetrics: [TrackingMetric: [TrackingDataPoint]]
    var provenance: [TrackingMetric: [TrackingProvenance]]
}

struct SelfTrackingAnalysis: Codable, Equatable {
    var insights: [TrackingInsight]
    var patternCandidates: [PatternCandidate]
}

struct TrackingMetrics: Codable, Equatable {
    let periodStart: Date
    let periodEnd: Date
    let summaryValue: Double?
    let unit: String
    let sampleCount: Int
    let daily: [TrackingDataPoint]
}

struct TrackingCue: Identifiable, Codable, Equatable {
    let id: String
    let source: TrackingSource
    let neutralDescription: String
    let startDate: Date?
    let endDate: Date?
    var relevance: TrackingCueRelevance
    var metrics: TrackingMetrics?
    var insight: TrackingInsight?

    init(
        id: String = UUID().uuidString,
        source: TrackingSource,
        observation: String,
        included: Bool = false,
        metrics: TrackingMetrics? = nil,
        insight: TrackingInsight? = nil
    ) {
        self.id = id
        self.source = source
        neutralDescription = observation
        startDate = metrics?.periodStart ?? insight?.observationWindow.start
        endDate = metrics?.periodEnd ?? insight?.observationWindow.end
        relevance = included ? .relevant : .notReviewed
        self.metrics = metrics
        self.insight = insight
    }

    var observation: String { neutralDescription }
    var included: Bool {
        get { relevance == .relevant }
        set { relevance = newValue ? .relevant : .irrelevant }
    }

    private enum CodingKeys: String, CodingKey {
        case id, source, neutralDescription, observation, startDate, endDate, relevance, included, metrics, insight
    }

    init(from decoder: Decoder) throws {
        let box = try decoder.container(keyedBy: CodingKeys.self)
        id = (try? box.decode(String.self, forKey: .id)) ?? UUID().uuidString
        source = try box.decode(TrackingSource.self, forKey: .source)
        neutralDescription = (try? box.decode(String.self, forKey: .neutralDescription))
            ?? (try? box.decode(String.self, forKey: .observation))
            ?? "未命名记录"
        metrics = try? box.decodeIfPresent(TrackingMetrics.self, forKey: .metrics)
        insight = try? box.decodeIfPresent(TrackingInsight.self, forKey: .insight)
        startDate = (try? box.decodeIfPresent(Date.self, forKey: .startDate)) ?? metrics?.periodStart
        endDate = (try? box.decodeIfPresent(Date.self, forKey: .endDate)) ?? metrics?.periodEnd
        if let decoded = try? box.decode(TrackingCueRelevance.self, forKey: .relevance) {
            relevance = decoded
        } else {
            relevance = (try? box.decode(Bool.self, forKey: .included)) == true ? .relevant : .notReviewed
        }
    }

    func encode(to encoder: Encoder) throws {
        var box = encoder.container(keyedBy: CodingKeys.self)
        try box.encode(id, forKey: .id)
        try box.encode(source, forKey: .source)
        try box.encode(neutralDescription, forKey: .neutralDescription)
        try box.encodeIfPresent(startDate, forKey: .startDate)
        try box.encodeIfPresent(endDate, forKey: .endDate)
        try box.encode(relevance, forKey: .relevance)
        try box.encodeIfPresent(metrics, forKey: .metrics)
        try box.encodeIfPresent(insight, forKey: .insight)
    }
}

/// One application-owned bundle of cleaned cues shown together in a single assistant reply.
/// The LLM may resolve the bundle as a whole; Swift binds that decision to these exact cue IDs.
struct TurnTrackingPresentation: Identifiable, Codable, Equatable, Sendable {
    let id: String
    let cueIDs: [String]
    let presentedAtUserTurnID: UUID?
    var resolution: TurnConfirmationDecision?

    init(
        id: String = UUID().uuidString,
        cueIDs: [String],
        presentedAtUserTurnID: UUID?,
        resolution: TurnConfirmationDecision? = nil
    ) {
        self.id = id
        self.cueIDs = cueIDs
        self.presentedAtUserTurnID = presentedAtUserTurnID
        self.resolution = resolution
    }
}

/// Internal design guidance for a projective image. It is a bounded question-generation space,
/// never an interpretation, diagnosis, or conclusion shown to the user.
enum SelfCompassionDimension: String, Codable, CaseIterable {
    case selfKindness
    case commonHumanity
    case mindfulness
}

/// A card-specific supplement for applying the three self-compassion dimensions. These are
/// candidate wording directions only. They neither replace the card's existing tender/fierce
/// guidance nor become a meaning assigned to the image.
struct CardSelfCompassionGuidance: Codable, Equatable {
    let primaryDimension: SelfCompassionDimension
    let secondaryDimensions: [SelfCompassionDimension]
    let selfKindnessCandidates: [String]
    let commonHumanityCandidates: [String]
    let mindfulnessCandidates: [String]
    let candidateQuestion: String
    let activationHint: String
}

/// An image-only prompt that may help when the person has described a card but cannot yet
/// connect it with their life. Every anchor group must be present in the person's own picture
/// narrative before the question can be shown. This deliberately keeps card semantics out of
/// the visible prompt.
struct CardVisualScaffold: Codable, Equatable, Hashable, Sendable {
    let requiredAnchorGroups: [[String]]
    let question: String
}

struct CardReflectionGuidance: Codable, Equatable {
    let coreTension: String
    let tenderLenses: [String]
    let fierceLenses: [String]
    let visualAnchors: [String]
    let possibleDirections: [String]
    let prohibitedClaims: [String]
    let selfCompassion: CardSelfCompassionGuidance?
    /// Optional so older persisted sessions decode safely. These are image-only questions that
    /// may be used once after a soft “想不到”; they never become a meaning assigned to the card.
    let visualScaffolds: [CardVisualScaffold]?

    init(
        coreTension: String,
        tenderLenses: [String],
        fierceLenses: [String],
        visualAnchors: [String],
        possibleDirections: [String],
        prohibitedClaims: [String],
        selfCompassion: CardSelfCompassionGuidance? = nil,
        visualScaffolds: [CardVisualScaffold]? = nil
    ) {
        self.coreTension = coreTension
        self.tenderLenses = tenderLenses
        self.fierceLenses = fierceLenses
        self.visualAnchors = visualAnchors
        self.possibleDirections = possibleDirections
        self.prohibitedClaims = prohibitedClaims
        self.selfCompassion = selfCompassion
        self.visualScaffolds = visualScaffolds
    }
}

/// A deterministic, locally-computed overlap between what the user actually described and the
/// selected card's internal catalogue. No overlap means no card lens is supplied to the model.
struct CardGuidanceMatch: Codable, Equatable {
    let matchedVisualAnchors: [String]
    let candidateDirections: [String]
    /// Optional for additive decoding of sessions saved before three-sided guidance matching.
    let imageRelation: String?
    let realityRelation: String?
    let matchedConcepts: [SemanticConcept]?
    /// Stable local catalogue selections. The model may phrase only these selected directions;
    /// it must not choose among or blend the full Tender/Fierce catalogues.
    let selectedTenderLensID: String?
    let selectedFierceLensID: String?
    let selectedSelfCompassionCandidateID: String?

    init(
        matchedVisualAnchors: [String],
        candidateDirections: [String],
        imageRelation: String? = nil,
        realityRelation: String? = nil,
        matchedConcepts: [SemanticConcept]? = nil,
        selectedTenderLensID: String? = nil,
        selectedFierceLensID: String? = nil,
        selectedSelfCompassionCandidateID: String? = nil
    ) {
        self.matchedVisualAnchors = matchedVisualAnchors
        self.candidateDirections = candidateDirections
        self.imageRelation = imageRelation
        self.realityRelation = realityRelation
        self.matchedConcepts = matchedConcepts
        self.selectedTenderLensID = selectedTenderLensID
        self.selectedFierceLensID = selectedFierceLensID
        self.selectedSelfCompassionCandidateID = selectedSelfCompassionCandidateID
    }
}

struct ReflectionCard: Identifiable, Codable, Equatable {
    let id: Int
    /// Kept neutral for model prompts so a title cannot become an explanation before the user
    /// describes the image.
    let neutralLabel: String
    /// User-visible card name. Older saved sessions safely fall back to their neutral label.
    let title: String
    let imageName: String
    /// Legacy single-tension field retained for additive session migration.
    let reflectiveThemes: String
    let internalGuidance: CardReflectionGuidance?

    init(
        id: Int,
        neutralLabel: String,
        title: String? = nil,
        imageName: String,
        reflectiveThemes: String,
        internalGuidance: CardReflectionGuidance? = nil
    ) {
        self.id = id
        self.neutralLabel = neutralLabel
        self.title = title ?? neutralLabel
        self.imageName = imageName
        self.reflectiveThemes = reflectiveThemes
        self.internalGuidance = internalGuidance
    }

    enum CodingKeys: String, CodingKey {
        case id, neutralLabel, title, imageName, reflectiveThemes, internalGuidance
    }

    init(from decoder: Decoder) throws {
        let box = try decoder.container(keyedBy: CodingKeys.self)
        id = try box.decode(Int.self, forKey: .id)
        neutralLabel = try box.decode(String.self, forKey: .neutralLabel)
        title = (try? box.decode(String.self, forKey: .title)) ?? neutralLabel
        imageName = try box.decode(String.self, forKey: .imageName)
        reflectiveThemes = (try? box.decode(String.self, forKey: .reflectiveThemes)) ?? ""
        internalGuidance = try? box.decodeIfPresent(CardReflectionGuidance.self, forKey: .internalGuidance)
    }
}

struct CardDrawRecord: Codable, Equatable {
    let sessionID: UUID
    let cardID: String
    let drawnAt: Date
    let routeBeforeDraw: CompassionRoute
}

struct StudyEvent: Identifiable, Codable {
    let id: UUID
    let timestamp: Date
    let stage: ReflectionStage
    let action: String

    init(id: UUID = UUID(), timestamp: Date = .now, stage: ReflectionStage, action: String) {
        self.id = id; self.timestamp = timestamp; self.stage = stage; self.action = action
    }
}

struct StudyMeasures: Codable, Equatable {
    var feltUnderstood = 4.0
    var compassionateCandor = 4.0
    var reactance = 4.0
    var responsibilityClarity = 4.0
    var interpretationOwnership = 4.0
    var cardFamiliarity = 1.0
}

enum HypothesisStatus: String, Codable { case pending, kept, revised, setAside }

struct Hypothesis: Identifiable, Codable, Equatable {
    let id: UUID
    var text: String
    var status: HypothesisStatus

    init(id: UUID = UUID(), text: String, status: HypothesisStatus = .pending) {
        self.id = id; self.text = text; self.status = status
    }
}

enum CompassionateActionCategory: String, Codable, CaseIterable {
    case care, protect, provide, repair, change

    var title: String {
        switch self {
        case .care: "先照顾自己"
        case .protect: "保护一点边界"
        case .provide: "补一点支持"
        case .repair: "修复一次沟通"
        case .change: "试一个小改变"
        }
    }
}

/// Internal support direction selected by Swift after semantic evidence has been validated.
/// `noAction` is a valid outcome and is intentionally not persisted as a user action.
enum CompassionatePracticeDirection: String, Equatable {
    case care
    case repair
    case protection
    case change
    case noAction

    var actionCategory: CompassionateActionCategory? {
        switch self {
        case .care: return .care
        case .repair: return .repair
        case .protection: return .protect
        case .change: return .change
        case .noAction: return nil
        }
    }
}

struct CompassionateAction: Codable, Equatable {
    var category: CompassionateActionCategory
    var description: String
    var timing: String?
    var acceptedByUser: Bool
}

struct ActionSuggestion: Identifiable, Codable, Equatable {
    let id: UUID
    let category: CompassionateActionCategory
    let description: String
    let timing: String?
    let rationale: String

    init(
        id: UUID = UUID(),
        category: CompassionateActionCategory,
        description: String,
        timing: String? = nil,
        rationale: String
    ) {
        self.id = id
        self.category = category
        self.description = description
        self.timing = timing
        self.rationale = rationale
    }
}

/// A domain-neutral relation extracted from the person's own words. These values describe how
/// already supplied pieces of evidence relate; they never authorize a workflow transition by
/// themselves. Swift validates the literal evidence before using a relation at a later gate.
enum SemanticRelationKind: String, Codable, CaseIterable, Sendable {
    case eventExperience
    case conditionCapacity
    case behaviorImpact
    case selfEvaluation
    case boundaryNeed
    case controllablePart
    case uncertainty
    case imageStructure
    case realityStructure
    case imageRealityMapping
    case meaningShift
    case sharedHumanity
    case unmetNeed
}

enum SemanticEvidenceStatus: String, Codable {
    case userStated
    case userConfirmed
    case tentative
    case rejected
}

/// A small shared ontology lets the Analyzer describe a relation without classifying the user into
/// a scenario such as “paper”, “family”, or “breakup”. Card metadata may intersect these concepts
/// only after a user-grounded image-to-reality mapping has been confirmed.
enum SemanticConcept: String, Codable, CaseIterable {
    case uncertainty
    case action
    case avoidance
    case preparation
    case rest
    case recovery
    case stagnation
    case responsibility
    case boundary
    case sharing
    case support
    case constraint
    case protection
    case control
    case shame
    case repair
    case communication
    case pattern
    case change
    case safety
    case lettingGo
    case loss
    case choice
    case ability
    case perfectionism
    case problemSolving
    case resources
    case overload
    case relationship
    case judgment
    case selfEvaluation
    case facts
    case commonHumanity
    case connection
    case isolation
    case autonomy
    case planning
    case priority
    case flexibility
}

struct SemanticRelation: Codable, Equatable, Identifiable {
    var id = UUID()
    var kind: SemanticRelationKind
    var source: String
    var relation: String
    var target: String
    var concepts: [SemanticConcept] = []
    var evidence: [String] = []
    var status: SemanticEvidenceStatus = .tentative
    var confidence = 0.0

    private enum CodingKeys: String, CodingKey {
        case id, kind, source, relation, target, concepts, evidence, status, confidence
    }

    init(
        id: UUID = UUID(),
        kind: SemanticRelationKind,
        source: String,
        relation: String,
        target: String,
        concepts: [SemanticConcept] = [],
        evidence: [String] = [],
        status: SemanticEvidenceStatus = .tentative,
        confidence: Double = 0
    ) {
        self.id = id
        self.kind = kind
        self.source = source
        self.relation = relation
        self.target = target
        self.concepts = concepts
        self.evidence = evidence
        self.status = status
        self.confidence = confidence
    }

    init(from decoder: Decoder) throws {
        let box = try decoder.container(keyedBy: CodingKeys.self)
        id = (try? box.decode(UUID.self, forKey: .id)) ?? UUID()
        kind = try box.decode(SemanticRelationKind.self, forKey: .kind)
        source = (try? box.decode(String.self, forKey: .source)) ?? ""
        relation = (try? box.decode(String.self, forKey: .relation)) ?? ""
        target = (try? box.decode(String.self, forKey: .target)) ?? ""
        concepts = (try? box.decode([SemanticConcept].self, forKey: .concepts)) ?? []
        evidence = (try? box.decode([String].self, forKey: .evidence)) ?? []
        status = (try? box.decode(SemanticEvidenceStatus.self, forKey: .status)) ?? .tentative
        confidence = (try? box.decode(Double.self, forKey: .confidence)) ?? 0
    }
}

struct ContextAnalysis: Codable, Equatable {
    var safetyOverride = false
    var distressLevel = 0
    var selfAttackLevel = 0
    var reflectiveCapacity = 1
    var behaviorIdentitySeparation = 0
    var multipleExplanationsCapacity = 0
    var consentToCandor: ConsentState = .unknown
    var eventType: ReflectionEventType = .unclear
    var taskProgressStatus: TaskProgressStatus = .notApplicable
    /// True only when the person themselves has named a concrete action, omission, impact, or
    /// boundary—not when the analyzer merely sees distress or a global self-label.
    var userAdmittedBehavior = false
    var confirmedBehavior: String?
    /// Short literal fragments from the user message(s) that support the semantic candidates.
    /// Swift verifies them against the transcript before using them for a fierce invitation.
    var behaviorEvidence: [String] = []
    var eventDescription: String?
    var emotions: [String] = []
    var bodilyResponses: [String] = []
    var selfJudgment: String?
    var contextualConstraints: [String] = []
    var personalContributions: [String] = []
    var possibleImpactOnOthers: [String] = []
    var possibleBoundaryConcerns: [String] = []
    var possibleUnmetNeeds: [String] = []
    var possibleRepeatingPatterns: [String] = []
    var uncertainties: [String] = []
    var pastControllability: ControllabilityLevel = .unknown
    var presentAgency: AgencyLevel = .unknown
    var recommendedRoute: CompassionRoute = .explore
    var secondaryRoutes: [CompassionRoute] = []
    var reasonCodes: [String] = []
    var missingInformation: [String] = []
    var nextQuestionGoal = "invite one concrete detail"
    /// Optional on disk so reflection sessions saved before semantic relations were introduced
    /// continue to decode. Runtime code should consume `resolvedSemanticRelations`.
    var semanticRelations: [SemanticRelation]?
    /// Optional for additive compatibility with analyses saved before typed response planning.
    /// A plan is never trusted directly; Swift validates it against the transcript and phase.
    var responsePlan: ResponsePlan?
    var confidence = 0.0

    var resolvedSemanticRelations: [SemanticRelation] {
        semanticRelations ?? []
    }

    var validated: ContextAnalysis {
        var copy = self
        copy.distressLevel = min(max(distressLevel, 0), 3)
        copy.selfAttackLevel = min(max(selfAttackLevel, 0), 3)
        copy.reflectiveCapacity = min(max(reflectiveCapacity, 0), 3)
        copy.behaviorIdentitySeparation = min(max(behaviorIdentitySeparation, 0), 3)
        copy.multipleExplanationsCapacity = min(max(multipleExplanationsCapacity, 0), 3)
        copy.confidence = min(max(confidence, 0), 1)
        copy.secondaryRoutes = Array(secondaryRoutes.prefix(3))
        copy.reasonCodes = Array(reasonCodes.prefix(8))
        copy.missingInformation = Array(missingInformation.prefix(8))
        copy.semanticRelations = Array(
            resolvedSemanticRelations.compactMap { relation -> SemanticRelation? in
                var value = relation
                value.source = value.source.trimmingCharacters(in: .whitespacesAndNewlines)
                value.relation = value.relation.trimmingCharacters(in: .whitespacesAndNewlines)
                value.target = value.target.trimmingCharacters(in: .whitespacesAndNewlines)
                value.evidence = Array(
                    value.evidence
                        .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                        .filter { !$0.isEmpty && $0.count <= 120 }
                        .prefix(3)
                )
                value.concepts = Array(Set(value.concepts).prefix(6))
                value.confidence = min(max(value.confidence, 0), 1)
                guard !value.source.isEmpty,
                      !value.relation.isEmpty,
                      !value.target.isEmpty else { return nil }
                return value
            }.prefix(16)
        )
        copy.responsePlan = responsePlan?.validated
        copy.confirmedBehavior = copy.confirmedBehavior?
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if copy.confirmedBehavior?.isEmpty == true { copy.confirmedBehavior = nil }
        copy.behaviorEvidence = Array(
            behaviorEvidence
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty && $0.count <= 120 }
                .prefix(3)
        )
        // A recommendation without a literal user-supported fragment remains only an uncertain
        // analyzer hypothesis; it cannot unlock a candid responsibility/change question.
        if copy.userAdmittedBehavior && copy.behaviorEvidence.isEmpty {
            copy.userAdmittedBehavior = false
            copy.confirmedBehavior = nil
        }
        return copy
    }

    static func fallback(safetyOverride: Bool = false) -> ContextAnalysis {
        var result = ContextAnalysis()
        result.safetyOverride = safetyOverride
        result.recommendedRoute = safetyOverride ? .tenderStabilize : .explore
        result.uncertainties = ["模型分析暂时不可用，保留当前信息的不确定性"]
        result.nextQuestionGoal = "invite one concrete, easy-to-answer detail"
        return result
    }
}

struct CompassionRouteResolver {
    func resolve(from analysis: ContextAnalysis) -> CompassionRoute {
        let value = analysis.validated
        if value.safetyOverride { return .tenderStabilize }
        if value.consentToCandor != .yes { return .tenderStabilize }
        if value.distressLevel >= 2 && value.selfAttackLevel >= 2 { return .tenderStabilize }
        if value.reflectiveCapacity <= 1 { return .tenderStabilize }

        // Route only from evidence-bearing, domain-neutral relations. Legacy summary arrays remain
        // available for old sessions and prompt context, but cannot independently assign a route.
        let relations = value.resolvedSemanticRelations.filter {
            [.userStated, .userConfirmed].contains($0.status) &&
            $0.confidence >= 0.6 &&
            !$0.evidence.isEmpty
        }
        if relations.contains(where: { $0.kind == .boundaryNeed }) { return .protect }
        if relations.contains(where: {
            $0.kind == .behaviorImpact &&
            ($0.concepts.contains(.repair) || $0.concepts.contains(.responsibility))
        }) {
            return .repair
        }
        if relations.contains(where: { $0.kind == .unmetNeed }) { return .provide }
        if relations.contains(where: {
            $0.kind == .controllablePart ||
            ($0.kind == .behaviorImpact && $0.concepts.contains(.change))
        }) {
            return .change
        }
        return .explore
    }
}

struct ReflectionStateMachine {
    func canTransition(from: ReflectionState, to: ReflectionState) -> Bool {
        if to == .safetySupport { return from != .completed }
        let allowed: [ReflectionState: Set<ReflectionState>] = [
            .welcome: [.eventDisclosure],
            .eventDisclosure: [.emotionDisclosure, .bodilyResponse, .selfJudgment, .contextDisclosure, .tenderGrounding, .trackingPermission, .summary],
            .emotionDisclosure: [.bodilyResponse, .selfJudgment, .contextDisclosure, .tenderGrounding, .trackingPermission, .summary],
            .bodilyResponse: [.selfJudgment, .contextDisclosure, .tenderGrounding, .trackingPermission, .summary],
            // `.bodilyResponse` is a recovery edge for legacy sessions saved after self-talk but
            // before the new body-depth gate existed. New sessions still reach body first.
            .selfJudgment: [.bodilyResponse, .contextDisclosure, .tenderGrounding, .trackingPermission, .summary],
            // Recovery edges let an additive schema migration deepen an older session that had
            // already reached context before the body/personal-meaning layers were introduced.
            // New sessions still follow the forward-only disclosure order above.
            .contextDisclosure: [.bodilyResponse, .selfJudgment, .tenderGrounding, .trackingPermission, .summary],
            .trackingPermission: [.trackingReview, .tenderGrounding, .readinessCheck, .summary],
            .trackingReview: [.tenderGrounding, .readinessCheck, .summary],
            .tenderGrounding: [.trackingPermission, .trackingReview, .readinessCheck, .summary],
            .readinessCheck: [.tenderGrounding, .tenderExploration, .trackingReview, .cardIntroduction, .attributionReflection, .summary],
            .tenderExploration: [.readinessCheck, .summary],
            .cardIntroduction: [.cardInterpretation, .summary],
            .cardInterpretation: [.attributionReflection, .tenderExploration, .summary],
            .attributionReflection: [.tenderExploration, .actionSelection, .summary],
            .actionSelection: [.summary],
            .summary: [.completed],
            .completed: [],
            .safetySupport: [.completed],
        ]
        return allowed[from, default: []].contains(to)
    }

    func nextDisclosureState(after state: ReflectionState) -> ReflectionState? {
        switch state {
        case .eventDisclosure: .emotionDisclosure
        case .emotionDisclosure: .bodilyResponse
        case .bodilyResponse: .selfJudgment
        case .selfJudgment: .contextDisclosure
        case .contextDisclosure: .trackingPermission
        default: nil
        }
    }
}

struct AdaptiveDisclosureResolver {
    func nextState(after state: ReflectionState, context: ReflectionContext) -> ReflectionState? {
        switch state {
        case .eventDisclosure:
            // Tracking should not enter merely because one opening message happens to contain a
            // judgment and a practical constraint. First make sure the person's lived experience
            // is clear enough in their own words; if it already is, skip only that redundant layer.
            if context.emotions.isEmpty { return .emotionDisclosure }
            if context.bodilyResponses.isEmpty { return .bodilyResponse }
            if context.personalMeaning?.isEmpty != false { return .selfJudgment }
            return context.contextualConstraints.isEmpty ? .contextDisclosure : .trackingPermission
        case .emotionDisclosure:
            if context.bodilyResponses.isEmpty { return .bodilyResponse }
            if context.personalMeaning?.isEmpty != false { return .selfJudgment }
            return context.contextualConstraints.isEmpty ? .contextDisclosure : .trackingPermission
        case .bodilyResponse:
            if context.personalMeaning?.isEmpty != false { return .selfJudgment }
            return context.contextualConstraints.isEmpty ? .contextDisclosure : .trackingPermission
        case .selfJudgment:
            return context.contextualConstraints.isEmpty ? .contextDisclosure : .trackingPermission
        case .contextDisclosure:
            return .trackingPermission
        default:
            return nil
        }
    }
}

struct ReflectionSession: Identifiable, Codable {
    var id = UUID()
    var createdAt = Date()
    var stage: ReflectionState = .welcome
    /// New sessions use the coarse LLM TurnController protocol. A decoded value of 1 preserves the
    /// exact behavior of older in-progress sessions instead of migrating their meaning mid-turn.
    var protocolVersion = 1
    var protocolStage: ReflectionProtocolStage = .contextualDisclosure
    var reflectionReadiness: ReflectionReadiness = .needsTender
    var semanticMemory = TurnSemanticMemory()
    var presentedTrackingCueIDs: Set<String> = []
    var trackingPresentations: [TurnTrackingPresentation] = []
    var activeTrackingPresentationID: String?
    var cardGuidanceShared = false
    var condition: ExperimentalCondition = .cardMediated
    /// Nil marks a pre-study/ordinary reflection. These additive fields distinguish deliberate
    /// crossover periods from historical card-mediated sessions.
    var studySequence: StudySequence?
    var studyPeriod: Int?
    /// `eventDate` is only treated as an event-time tracking anchor when the person explicitly
    /// supplied a date or relative day. Otherwise it remains the session reference and visible
    /// language stays at “最近 / 这段时间”.
    var eventDateIsUserSpecified = false
    var messages: [ChatMessage] = []
    var context = ReflectionContext()
    var trackingCues: [TrackingCue] = []
    var trackingUseDeclined = false
    var pendingTrackingCueID: String?
    /// A review can contain several cleaned cues from distinct domains. The singular field stays
    /// for migration and mirrors the first pending cue in new sessions.
    var pendingTrackingCueIDs: [String] = []
    var card: ReflectionCard?
    var cardDrawRecord: CardDrawRecord?
    var cardWasSetAside = false
    var cardDisplayState: CardDisplayState = .none
    var cardDisplayReloadNonce = 0
    var workflowPhase: ReflectionWorkflowPhase = .opening
    /// Number of assistant turns that invited or continued structured disclosure. The opening
    /// invitation counts as the first turn; Swift exits after 3 sufficient turns and always by 5.
    var structuredDisclosureAssistantTurns = 0
    var bodyExplorationCompleted = false
    var personalMeaningExplorationCompleted = false
    var hasAskedPersonalMeaningQuestion = false
    var tenderGroundingRevisionCount = 0
    var tenderGroundingConfirmed = false
    var trackingReviewCompleted = false
    var trackingReviewUnavailable = false
    var trackingContextLinkCompleted = false
    var trackingContextLinkResponse: String?
    var contextConfirmationRevisionCount = 0
    var contextSummaryConfirmed = false
    /// The synthesis confirmed after disclosure and tracking. Card narration treats this as a
    /// locked baseline and may reference it briefly, but cannot rebuild it field by field.
    var lockedBaselineNarrative: String?
    var cardConnectionAttemptCount = 0
    /// Protocol-v2 capability flag. Once true, neither a second visual scaffold nor another
    /// guidance-based bridge may be requested for the same card connection.
    var cardConnectionScaffoldUsed = false
    /// True only while the app is waiting for one image-structure answer after the user's first
    /// soft “想不到”. That answer extends the user-authored picture narrative; it is never stored
    /// as a real-life connection.
    var cardConnectionScaffoldPending = false
    var cardConnectionUnavailable = false
    var cardLifeConnection: String?
    /// A system-proposed bridge is deliberately separate from the user's raw image-to-life
    /// association. It is never treated as their meaning until they accept or revise it.
    var cardCandidateMapping: String?
    var cardConfirmedMapping: String?
    var cardMappingConfirmed = false
    /// A local, deterministic overlap between the user's image words and the selected card's
    /// internal guidance. Absence is meaningful: it prevents card metadata entering dialogue.
    var cardGuidanceMatch: CardGuidanceMatch?
    var cardMeaningShiftResponse: String?
    var cardMeaningShiftCompleted = false
    /// What the card phase added beyond the locked baseline. Kept separate to prevent summary
    /// concatenation when the final record is generated.
    var cardDerivedDeltaNarrative: String?
    var candidCircumstancesCompleted = false
    var candidCircumstancesResponse: String?
    var candidAgencyCompleted = false
    var candidAgencyResponse: String?
    var integratedNarrativeConfirmed = false
    var pendingUserAuthoredAction: String?
    var userAuthoredActionConfirmed = false
    var hasPresentedFinalNarrative = false
    var finalNarrativeConfirmed = false
    var hasAskedProgressMeaningQuestion = false
    var hasAskedCardProjectionFollowUp = false
    var hasAskedCardNarrativeDeepening = false
    var hasUserAuthoredCardConnection = false
    var hasCompletedAttributionExchange = false
    var hasPresentedIntegratedNarrative = false
    var currentRoute: CompassionRoute = .tenderStabilize
    var latestAnalysis: ContextAnalysis?
    var dialogueProgress = DialogueProgress()
    var hypotheses: [Hypothesis] = []
    var actionSuggestions: [ActionSuggestion] = []
    var studyEvents: [StudyEvent] = []
    var studyMeasures = StudyMeasures()

    private enum CodingKeys: String, CodingKey {
        case id, createdAt, stage, protocolVersion, protocolStage, reflectionReadiness, semanticMemory
        case presentedTrackingCueIDs, trackingPresentations, activeTrackingPresentationID
        case cardGuidanceShared
        case condition, studySequence, studyPeriod, eventDateIsUserSpecified, messages, context, canvas, trackingCues
        case trackingUseDeclined, pendingTrackingCueID, pendingTrackingCueIDs
        case card, cardDrawRecord, cardWasSetAside, cardInterpretation
        case cardDisplayState, cardDisplayReloadNonce
        case workflowPhase, structuredDisclosureAssistantTurns
        case bodyExplorationCompleted, personalMeaningExplorationCompleted
        case hasAskedPersonalMeaningQuestion
        case tenderGroundingRevisionCount, tenderGroundingConfirmed, trackingReviewCompleted
        case trackingReviewUnavailable, trackingContextLinkCompleted, trackingContextLinkResponse
        case contextConfirmationRevisionCount, contextSummaryConfirmed, lockedBaselineNarrative
        case cardConnectionAttemptCount, cardConnectionScaffoldUsed
        case cardConnectionScaffoldPending, cardConnectionUnavailable
        case cardLifeConnection, cardCandidateMapping, cardConfirmedMapping, cardMappingConfirmed
        case cardGuidanceMatch, cardMeaningShiftResponse, cardMeaningShiftCompleted
        case cardDerivedDeltaNarrative
        case candidCircumstancesCompleted, candidCircumstancesResponse
        case candidAgencyCompleted, candidAgencyResponse
        case integratedNarrativeConfirmed, pendingUserAuthoredAction
        case userAuthoredActionConfirmed, hasPresentedFinalNarrative, finalNarrativeConfirmed
        case hasAskedProgressMeaningQuestion
        case hasAskedCardProjectionFollowUp, hasAskedCardNarrativeDeepening, hasUserAuthoredCardConnection
        case hasCompletedAttributionExchange, hasPresentedIntegratedNarrative, currentRoute
        case latestAnalysis, dialogueProgress, hypotheses, actionSuggestions, studyEvents, studyMeasures
    }

    init() {}

    var usesLLMTurnController: Bool { protocolVersion >= 2 }

    init(from decoder: Decoder) throws {
        let box = try decoder.container(keyedBy: CodingKeys.self)
        id = (try? box.decode(UUID.self, forKey: .id)) ?? UUID()
        createdAt = (try? box.decode(Date.self, forKey: .createdAt)) ?? Date()
        stage = (try? box.decode(ReflectionState.self, forKey: .stage)) ?? .welcome
        protocolVersion = (try? box.decode(Int.self, forKey: .protocolVersion)) ?? 1
        protocolStage = (try? box.decode(ReflectionProtocolStage.self, forKey: .protocolStage))
            ?? Self.inferredProtocolStage(from: stage)
        reflectionReadiness =
            (try? box.decode(ReflectionReadiness.self, forKey: .reflectionReadiness))
            ?? (protocolStage == .narrativeConfirmation || protocolStage == .optionalAction
                ? .narrativeReady
                : (protocolStage == .contextualDisclosure || protocolStage == .tenderConfirmation
                    ? .needsTender
                    : .needsFierce))
        semanticMemory = (try? box.decode(TurnSemanticMemory.self, forKey: .semanticMemory))
            ?? TurnSemanticMemory()
        presentedTrackingCueIDs =
            (try? box.decode(Set<String>.self, forKey: .presentedTrackingCueIDs)) ?? []
        trackingPresentations =
            (try? box.decode([TurnTrackingPresentation].self, forKey: .trackingPresentations)) ?? []
        activeTrackingPresentationID =
            try? box.decodeIfPresent(String.self, forKey: .activeTrackingPresentationID)
        cardGuidanceShared =
            (try? box.decode(Bool.self, forKey: .cardGuidanceShared)) ?? false
        condition = (try? box.decode(ExperimentalCondition.self, forKey: .condition)) ?? .cardMediated
        studySequence = try? box.decodeIfPresent(StudySequence.self, forKey: .studySequence)
        studyPeriod = try? box.decodeIfPresent(Int.self, forKey: .studyPeriod)
        eventDateIsUserSpecified = (try? box.decode(Bool.self, forKey: .eventDateIsUserSpecified)) ?? false
        messages = (try? box.decode([ChatMessage].self, forKey: .messages)) ?? []
        if let decoded = try? box.decode(ReflectionContext.self, forKey: .context) {
            context = decoded
        } else if let legacy = try? box.decode(ContextCanvas.self, forKey: .canvas) {
            context = ReflectionContext(legacy: legacy)
        }
        trackingCues = (try? box.decode([TrackingCue].self, forKey: .trackingCues)) ?? []
        trackingUseDeclined = (try? box.decode(Bool.self, forKey: .trackingUseDeclined)) ?? false
        pendingTrackingCueID = try? box.decodeIfPresent(String.self, forKey: .pendingTrackingCueID)
        pendingTrackingCueIDs =
            (try? box.decode([String].self, forKey: .pendingTrackingCueIDs))
            ?? pendingTrackingCueID.map { [$0] }
            ?? []
        card = try? box.decodeIfPresent(ReflectionCard.self, forKey: .card)
        cardDrawRecord = try? box.decodeIfPresent(CardDrawRecord.self, forKey: .cardDrawRecord)
        cardWasSetAside = (try? box.decode(Bool.self, forKey: .cardWasSetAside)) ?? false
        cardDisplayState = (try? box.decode(CardDisplayState.self, forKey: .cardDisplayState))
            ?? (card == nil ? .none : (stage == .cardIntroduction ? .selected : .displayed))
        cardDisplayReloadNonce =
            (try? box.decode(Int.self, forKey: .cardDisplayReloadNonce)) ?? 0
        structuredDisclosureAssistantTurns =
            (try? box.decode(Int.self, forKey: .structuredDisclosureAssistantTurns))
            ?? messages.filter {
                $0.role == .assistant && [
                    ReflectionState.eventDisclosure, .emotionDisclosure, .bodilyResponse,
                    .selfJudgment, .contextDisclosure,
                ].contains($0.state)
            }.count
        bodyExplorationCompleted =
            (try? box.decode(Bool.self, forKey: .bodyExplorationCompleted))
            ?? !context.bodilyResponses.isEmpty
        personalMeaningExplorationCompleted =
            (try? box.decode(Bool.self, forKey: .personalMeaningExplorationCompleted))
            ?? (context.personalMeaning?.isEmpty == false)
        hasAskedPersonalMeaningQuestion =
            (try? box.decode(Bool.self, forKey: .hasAskedPersonalMeaningQuestion))
            ?? personalMeaningExplorationCompleted
        tenderGroundingRevisionCount =
            (try? box.decode(Int.self, forKey: .tenderGroundingRevisionCount)) ?? 0
        tenderGroundingConfirmed =
            (try? box.decode(Bool.self, forKey: .tenderGroundingConfirmed)) ?? false
        trackingReviewCompleted =
            (try? box.decode(Bool.self, forKey: .trackingReviewCompleted))
            ?? (stage != .trackingPermission && stage != .trackingReview && stage != .tenderGrounding)
        trackingReviewUnavailable =
            (try? box.decode(Bool.self, forKey: .trackingReviewUnavailable)) ?? false
        trackingContextLinkCompleted =
            (try? box.decode(Bool.self, forKey: .trackingContextLinkCompleted))
            ?? (stage != .trackingReview)
        trackingContextLinkResponse =
            try? box.decodeIfPresent(String.self, forKey: .trackingContextLinkResponse)
        contextConfirmationRevisionCount =
            (try? box.decode(Int.self, forKey: .contextConfirmationRevisionCount)) ?? 0
        contextSummaryConfirmed =
            (try? box.decode(Bool.self, forKey: .contextSummaryConfirmed))
            ?? [
                ReflectionState.cardIntroduction, .cardInterpretation, .attributionReflection,
                .actionSelection, .summary, .completed,
            ].contains(stage)
        lockedBaselineNarrative =
            try? box.decodeIfPresent(String.self, forKey: .lockedBaselineNarrative)
        cardConnectionAttemptCount =
            (try? box.decode(Int.self, forKey: .cardConnectionAttemptCount)) ?? 0
        cardConnectionScaffoldUsed =
            (try? box.decode(Bool.self, forKey: .cardConnectionScaffoldUsed)) ?? false
        cardConnectionScaffoldPending =
            (try? box.decode(Bool.self, forKey: .cardConnectionScaffoldPending)) ?? false
        cardConnectionUnavailable =
            (try? box.decode(Bool.self, forKey: .cardConnectionUnavailable)) ?? cardWasSetAside
        cardLifeConnection = try? box.decodeIfPresent(String.self, forKey: .cardLifeConnection)
        cardCandidateMapping = try? box.decodeIfPresent(String.self, forKey: .cardCandidateMapping)
        // Older sessions reached candid reflection directly after a user-authored connection.
        // Treat that already-progressed route as confirmed while new sessions persist this flag.
        cardMappingConfirmed =
            (try? box.decode(Bool.self, forKey: .cardMappingConfirmed))
            ?? (cardLifeConnection?.isEmpty == false && stage == .attributionReflection)
        cardConfirmedMapping = try? box.decodeIfPresent(String.self, forKey: .cardConfirmedMapping)
            ?? (cardMappingConfirmed ? cardLifeConnection : nil)
        cardGuidanceMatch = try? box.decodeIfPresent(CardGuidanceMatch.self, forKey: .cardGuidanceMatch)
        cardMeaningShiftResponse =
            try? box.decodeIfPresent(String.self, forKey: .cardMeaningShiftResponse)
        cardMeaningShiftCompleted =
            (try? box.decode(Bool.self, forKey: .cardMeaningShiftCompleted))
            ?? (cardMeaningShiftResponse?.isEmpty == false)
        cardDerivedDeltaNarrative =
            try? box.decodeIfPresent(String.self, forKey: .cardDerivedDeltaNarrative)
        candidCircumstancesResponse =
            try? box.decodeIfPresent(String.self, forKey: .candidCircumstancesResponse)
        candidCircumstancesCompleted =
            (try? box.decode(Bool.self, forKey: .candidCircumstancesCompleted))
            ?? (candidCircumstancesResponse?.isEmpty == false)
        candidAgencyResponse = try? box.decodeIfPresent(String.self, forKey: .candidAgencyResponse)
        candidAgencyCompleted =
            (try? box.decode(Bool.self, forKey: .candidAgencyCompleted))
            ?? (candidAgencyResponse?.isEmpty == false)
        integratedNarrativeConfirmed =
            (try? box.decode(Bool.self, forKey: .integratedNarrativeConfirmed))
            ?? (stage == .actionSelection || stage == .summary || stage == .completed)
        pendingUserAuthoredAction =
            try? box.decodeIfPresent(String.self, forKey: .pendingUserAuthoredAction)
        userAuthoredActionConfirmed =
            (try? box.decode(Bool.self, forKey: .userAuthoredActionConfirmed))
            ?? (context.selectedAction?.acceptedByUser == true)
        hasPresentedFinalNarrative =
            (try? box.decode(Bool.self, forKey: .hasPresentedFinalNarrative))
            ?? (stage == .summary || stage == .completed)
        finalNarrativeConfirmed =
            (try? box.decode(Bool.self, forKey: .finalNarrativeConfirmed))
            ?? (stage == .completed)
        hasAskedProgressMeaningQuestion =
            (try? box.decode(Bool.self, forKey: .hasAskedProgressMeaningQuestion)) ?? false
        hasAskedCardProjectionFollowUp =
            (try? box.decode(Bool.self, forKey: .hasAskedCardProjectionFollowUp)) ?? false
        hasAskedCardNarrativeDeepening =
            (try? box.decode(Bool.self, forKey: .hasAskedCardNarrativeDeepening)) ?? false
        hasCompletedAttributionExchange =
            (try? box.decode(Bool.self, forKey: .hasCompletedAttributionExchange))
            ?? (candidCircumstancesCompleted && candidAgencyCompleted)
        hasPresentedIntegratedNarrative =
            (try? box.decode(Bool.self, forKey: .hasPresentedIntegratedNarrative)) ?? false
        hasUserAuthoredCardConnection =
            (try? box.decode(Bool.self, forKey: .hasUserAuthoredCardConnection))
            ?? (cardLifeConnection?.isEmpty == false || hasCompletedAttributionExchange || hasPresentedIntegratedNarrative)
        currentRoute = (try? box.decode(CompassionRoute.self, forKey: .currentRoute)) ?? .tenderStabilize
        workflowPhase = (try? box.decode(ReflectionWorkflowPhase.self, forKey: .workflowPhase))
            ?? Self.inferredWorkflowPhase(
                stage: stage,
                cardDisplayState: cardDisplayState,
                hasAskedCardProjectionFollowUp: hasAskedCardProjectionFollowUp,
                hasAskedCardNarrativeDeepening: hasAskedCardNarrativeDeepening,
                hasUserAuthoredCardConnection: hasUserAuthoredCardConnection,
                cardMappingConfirmed: cardMappingConfirmed,
                candidCircumstancesCompleted: candidCircumstancesCompleted,
                cardMeaningShiftCompleted: cardMeaningShiftCompleted,
                hasCompletedAttributionExchange: hasCompletedAttributionExchange,
                hasPresentedIntegratedNarrative: hasPresentedIntegratedNarrative
            )
        latestAnalysis = try? box.decodeIfPresent(ContextAnalysis.self, forKey: .latestAnalysis)
        dialogueProgress = (try? box.decode(DialogueProgress.self, forKey: .dialogueProgress))
            ?? DialogueProgress()
        dialogueProgress.currentState = stage
        hypotheses = (try? box.decode([Hypothesis].self, forKey: .hypotheses)) ?? []
        actionSuggestions = (try? box.decode([ActionSuggestion].self, forKey: .actionSuggestions)) ?? []
        studyEvents = (try? box.decode([StudyEvent].self, forKey: .studyEvents)) ?? []
        studyMeasures = (try? box.decode(StudyMeasures.self, forKey: .studyMeasures)) ?? StudyMeasures()
        if context.cardInterpretation == nil {
            context.cardInterpretation = try? box.decodeIfPresent(String.self, forKey: .cardInterpretation)
        }
        for index in trackingCues.indices {
            guard var insight = trackingCues[index].insight else { continue }
            insight.userRelevance = trackingCues[index].relevance
            trackingCues[index].insight = insight
        }
        let savedTrackingInterpretations = (context.confirmedTrackingInsights ?? []).reduce(
            into: [UUID: String]()
        ) { values, item in
            if let interpretation = item.userInterpretation {
                values[item.insightID] = interpretation
            }
        }
        context.confirmedTrackingCues = trackingCues.filter { $0.relevance == .relevant }
        context.confirmedTrackingInsights = trackingCues.compactMap { cue in
            guard cue.relevance == .relevant, let insight = cue.insight else { return nil }
            return ConfirmedTrackingContext(
                insightID: insight.id,
                observation: insight.neutralObservation,
                userInterpretation: savedTrackingInterpretations[insight.id],
                relevance: .relevant
            )
        }
        context.rejectedTrackingCueIDs = Set(
            trackingCues.filter { $0.relevance == .irrelevant }.map(\.id)
        )
    }

    func encode(to encoder: Encoder) throws {
        var box = encoder.container(keyedBy: CodingKeys.self)
        try box.encode(id, forKey: .id)
        try box.encode(createdAt, forKey: .createdAt)
        try box.encode(stage, forKey: .stage)
        try box.encode(protocolVersion, forKey: .protocolVersion)
        try box.encode(protocolStage, forKey: .protocolStage)
        try box.encode(reflectionReadiness, forKey: .reflectionReadiness)
        try box.encode(semanticMemory, forKey: .semanticMemory)
        try box.encode(presentedTrackingCueIDs, forKey: .presentedTrackingCueIDs)
        try box.encode(trackingPresentations, forKey: .trackingPresentations)
        try box.encodeIfPresent(
            activeTrackingPresentationID,
            forKey: .activeTrackingPresentationID
        )
        try box.encode(cardGuidanceShared, forKey: .cardGuidanceShared)
        try box.encode(condition, forKey: .condition)
        try box.encodeIfPresent(studySequence, forKey: .studySequence)
        try box.encodeIfPresent(studyPeriod, forKey: .studyPeriod)
        try box.encode(eventDateIsUserSpecified, forKey: .eventDateIsUserSpecified)
        try box.encode(messages, forKey: .messages)
        try box.encode(context, forKey: .context)
        try box.encode(trackingCues, forKey: .trackingCues)
        try box.encode(trackingUseDeclined, forKey: .trackingUseDeclined)
        try box.encodeIfPresent(pendingTrackingCueID, forKey: .pendingTrackingCueID)
        try box.encode(pendingTrackingCueIDs, forKey: .pendingTrackingCueIDs)
        try box.encodeIfPresent(card, forKey: .card)
        try box.encodeIfPresent(cardDrawRecord, forKey: .cardDrawRecord)
        try box.encode(cardWasSetAside, forKey: .cardWasSetAside)
        try box.encode(cardDisplayState, forKey: .cardDisplayState)
        try box.encode(cardDisplayReloadNonce, forKey: .cardDisplayReloadNonce)
        try box.encode(workflowPhase, forKey: .workflowPhase)
        try box.encode(structuredDisclosureAssistantTurns, forKey: .structuredDisclosureAssistantTurns)
        try box.encode(bodyExplorationCompleted, forKey: .bodyExplorationCompleted)
        try box.encode(personalMeaningExplorationCompleted, forKey: .personalMeaningExplorationCompleted)
        try box.encode(hasAskedPersonalMeaningQuestion, forKey: .hasAskedPersonalMeaningQuestion)
        try box.encode(tenderGroundingRevisionCount, forKey: .tenderGroundingRevisionCount)
        try box.encode(tenderGroundingConfirmed, forKey: .tenderGroundingConfirmed)
        try box.encode(trackingReviewCompleted, forKey: .trackingReviewCompleted)
        try box.encode(trackingReviewUnavailable, forKey: .trackingReviewUnavailable)
        try box.encode(trackingContextLinkCompleted, forKey: .trackingContextLinkCompleted)
        try box.encodeIfPresent(trackingContextLinkResponse, forKey: .trackingContextLinkResponse)
        try box.encode(contextConfirmationRevisionCount, forKey: .contextConfirmationRevisionCount)
        try box.encode(contextSummaryConfirmed, forKey: .contextSummaryConfirmed)
        try box.encodeIfPresent(lockedBaselineNarrative, forKey: .lockedBaselineNarrative)
        try box.encode(cardConnectionAttemptCount, forKey: .cardConnectionAttemptCount)
        try box.encode(cardConnectionScaffoldUsed, forKey: .cardConnectionScaffoldUsed)
        try box.encode(cardConnectionScaffoldPending, forKey: .cardConnectionScaffoldPending)
        try box.encode(cardConnectionUnavailable, forKey: .cardConnectionUnavailable)
        try box.encodeIfPresent(cardLifeConnection, forKey: .cardLifeConnection)
        try box.encodeIfPresent(cardCandidateMapping, forKey: .cardCandidateMapping)
        try box.encodeIfPresent(cardConfirmedMapping, forKey: .cardConfirmedMapping)
        try box.encode(cardMappingConfirmed, forKey: .cardMappingConfirmed)
        try box.encodeIfPresent(cardGuidanceMatch, forKey: .cardGuidanceMatch)
        try box.encodeIfPresent(cardMeaningShiftResponse, forKey: .cardMeaningShiftResponse)
        try box.encode(cardMeaningShiftCompleted, forKey: .cardMeaningShiftCompleted)
        try box.encodeIfPresent(cardDerivedDeltaNarrative, forKey: .cardDerivedDeltaNarrative)
        try box.encode(candidCircumstancesCompleted, forKey: .candidCircumstancesCompleted)
        try box.encodeIfPresent(candidCircumstancesResponse, forKey: .candidCircumstancesResponse)
        try box.encode(candidAgencyCompleted, forKey: .candidAgencyCompleted)
        try box.encodeIfPresent(candidAgencyResponse, forKey: .candidAgencyResponse)
        try box.encode(integratedNarrativeConfirmed, forKey: .integratedNarrativeConfirmed)
        try box.encodeIfPresent(pendingUserAuthoredAction, forKey: .pendingUserAuthoredAction)
        try box.encode(userAuthoredActionConfirmed, forKey: .userAuthoredActionConfirmed)
        try box.encode(hasPresentedFinalNarrative, forKey: .hasPresentedFinalNarrative)
        try box.encode(finalNarrativeConfirmed, forKey: .finalNarrativeConfirmed)
        try box.encode(hasAskedProgressMeaningQuestion, forKey: .hasAskedProgressMeaningQuestion)
        try box.encode(hasAskedCardProjectionFollowUp, forKey: .hasAskedCardProjectionFollowUp)
        try box.encode(hasAskedCardNarrativeDeepening, forKey: .hasAskedCardNarrativeDeepening)
        try box.encode(hasUserAuthoredCardConnection, forKey: .hasUserAuthoredCardConnection)
        try box.encode(hasCompletedAttributionExchange, forKey: .hasCompletedAttributionExchange)
        try box.encode(hasPresentedIntegratedNarrative, forKey: .hasPresentedIntegratedNarrative)
        try box.encode(currentRoute, forKey: .currentRoute)
        try box.encodeIfPresent(latestAnalysis, forKey: .latestAnalysis)
        try box.encode(dialogueProgress, forKey: .dialogueProgress)
        try box.encode(hypotheses, forKey: .hypotheses)
        try box.encode(actionSuggestions, forKey: .actionSuggestions)
        try box.encode(studyEvents, forKey: .studyEvents)
        try box.encode(studyMeasures, forKey: .studyMeasures)
    }

    private static func inferredWorkflowPhase(
        stage: ReflectionState,
        cardDisplayState: CardDisplayState,
        hasAskedCardProjectionFollowUp: Bool,
        hasAskedCardNarrativeDeepening: Bool,
        hasUserAuthoredCardConnection: Bool,
        cardMappingConfirmed: Bool,
        candidCircumstancesCompleted: Bool,
        cardMeaningShiftCompleted: Bool,
        hasCompletedAttributionExchange: Bool,
        hasPresentedIntegratedNarrative: Bool
    ) -> ReflectionWorkflowPhase {
        switch stage {
        case .welcome: return .opening
        case .eventDisclosure, .emotionDisclosure, .bodilyResponse, .selfJudgment, .contextDisclosure:
            return .structuredDisclosure
        case .tenderGrounding, .tenderExploration: return .tenderGroundingConfirmation
        case .trackingPermission, .trackingReview: return .trackingReview
        case .readinessCheck: return .contextConfirmation
        case .cardIntroduction:
            return cardDisplayState == .none ? .cardSelection : .cardDisplay
        case .cardInterpretation:
            if hasAskedCardNarrativeDeepening { return .cardNarrativeDeepening }
            return hasAskedCardProjectionFollowUp ? .cardAssociation : .cardObservation
        case .attributionReflection:
            if hasPresentedIntegratedNarrative { return .reflectionNarrativeConfirmation }
            // Older payloads did not persist the finer gates. Resume them at the earliest missing
            // safe gate instead of letting a legacy stage skip meaning shift or narrative review.
            if hasCompletedAttributionExchange { return .reflectionNarrativeConfirmation }
            if hasUserAuthoredCardConnection {
                guard cardMappingConfirmed else { return .cardMappingConfirmation }
                guard candidCircumstancesCompleted else { return .candidCircumstances }
                return cardMeaningShiftCompleted ? .candidAgency : .cardMeaningShift
            }
            return .cardConnection
        case .actionSelection: return .optionalAction
        case .summary: return .narrativeConfirmation
        case .completed: return .complete
        case .safetySupport: return .safetySupport
        }
    }

    private static func inferredProtocolStage(from stage: ReflectionState) -> ReflectionProtocolStage {
        switch stage {
        case .welcome, .eventDisclosure, .emotionDisclosure, .bodilyResponse, .selfJudgment,
             .contextDisclosure, .trackingPermission, .trackingReview:
            return .contextualDisclosure
        case .tenderGrounding, .tenderExploration:
            return .tenderConfirmation
        case .readinessCheck, .cardIntroduction:
            return .cardConsent
        case .cardInterpretation:
            return .cardReflection
        case .attributionReflection:
            return .directReflection
        case .actionSelection:
            return .optionalAction
        case .summary:
            return .narrativeConfirmation
        case .completed:
            return .complete
        case .safetySupport:
            return .safetySupport
        }
    }
}

struct DialogueActionOption: Codable, Equatable {
    let category: CompassionateActionCategory
    let description: String
    let timing: String?
    let rationale: String
}

struct DialogueTurn: Codable, Equatable {
    var reflection: String
    var question: String
    var actionOptions: [DialogueActionOption]

    var visibleText: String {
        [reflection, question]
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .joined(separator: "\n\n")
    }
}
