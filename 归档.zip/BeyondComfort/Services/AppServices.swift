import Foundation
import HealthKit
import EventKit

actor RemoteAPIService {
    static let shared = RemoteAPIService()

    private let session: URLSession
    private let baseURL: URL?

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.httpCookieStorage = .shared
        configuration.httpShouldSetCookies = true
        session = URLSession(configuration: configuration)
        let raw = (Bundle.main.object(forInfoDictionaryKey: "API_BASE_URL") as? String ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        baseURL = raw.isEmpty || raw.contains("$(") ? nil : URL(string: raw)
    }

    var isConfigured: Bool { baseURL != nil }

    func register(username: String, password: String) async throws -> AccountUser {
        try await request("/api/auth/register", method: "POST", body: ["username": username, "password": password, "consentAccepted": true])
    }

    func login(username: String, password: String) async throws -> AccountUser {
        try await request("/api/auth/login", method: "POST", body: ["username": username, "password": password])
    }

    func currentUser() async throws -> AccountUser { try await request("/api/auth/me") }

    func currentStudyAccess() async throws -> StudyAccess {
        try await request("/api/study/me")
    }

    func studyParticipants() async throws -> [StudyParticipant] {
        try await request("/api/admin/study-participants")
    }

    func studySchedules() async throws -> [StudySchedule] {
        try await request("/api/admin/study-schedules")
    }

    func updateStudySchedule(
        participantID: String,
        update: StudyScheduleUpdate
    ) async throws -> StudySchedule {
        let body = try jsonObject(update)
        return try await request(
            "/api/admin/study-schedules/\(participantID)",
            method: "PUT",
            body: body
        )
    }

    func logout() async throws {
        let _: EmptyResponse = try await request("/api/auth/logout", method: "POST")
    }

    func createReflectionSession(_ reflection: ReflectionSession) async throws -> String {
        struct Response: Decodable { let sessionId: String }
        let context = try jsonObject(reflection.context)
        var body: [String: Any] = ["condition": reflection.condition.rawValue, "context": context]
        if let sequence = reflection.studySequence, let period = reflection.studyPeriod {
            body["studySequence"] = sequence.rawValue
            body["studyPeriod"] = period
        }
        let response: Response = try await request("/api/sessions", method: "POST", body: body)
        return response.sessionId
    }

    func syncReflectionSession(id: String, reflection: ReflectionSession, action: String) async throws {
        let payload = try jsonObject(reflection)
        let _: SessionUpdateResponse = try await request("/api/sessions/\(id)", method: "PATCH", body: ["stage": reflection.stage.rawValue, "action": action, "payload": payload])
    }

    func deleteReflectionSession(id: String) async throws {
        let _: EmptyResponse = try await request("/api/sessions/\(id)", method: "DELETE")
    }

    func listReflectionSessions() async throws -> [RemoteSessionSummary] {
        try await request("/api/sessions")
    }

    func completeJSON(system: String, user: String, maxTokens: Int, temperature: Double, agentMode: String = "balanced") async throws -> String {
        struct Response: Decodable { let content: String }
        let body: [String: Any] = [
            "messages": [
                ["role": "system", "content": system],
                ["role": "user", "content": user]
            ],
            "maxTokens": maxTokens,
            "temperature": temperature,
            "agentMode": agentMode
        ]
        var lastError: Error?
        for attempt in 0..<2 {
            do {
                let response: Response = try await request(
                    "/api/llm/chat",
                    method: "POST",
                    body: body,
                    timeoutInterval: 150
                )
                return response.content
            } catch {
                lastError = error
                guard attempt == 0, isTransientLLMError(error) else { throw error }
                try await Task.sleep(for: .milliseconds(450))
            }
        }
        throw lastError ?? RemoteAPIError.invalidResponse
    }

    private func isTransientLLMError(_ error: Error) -> Bool {
        if let apiError = error as? RemoteAPIError,
           case .server(let status, _) = apiError {
            return status == 408 || status == 429 || (500...599).contains(status)
        }
        if let urlError = error as? URLError {
            return [
                .timedOut,
                .cannotFindHost,
                .cannotConnectToHost,
                .networkConnectionLost,
                .dnsLookupFailed,
                .notConnectedToInternet,
            ].contains(urlError.code)
        }
        return false
    }

    private func jsonObject<T: Encodable>(_ value: T) throws -> Any {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        return try JSONSerialization.jsonObject(with: encoder.encode(value))
    }

    private func request<Response: Decodable>(
        _ path: String,
        method: String = "GET",
        body: Any? = nil,
        timeoutInterval: TimeInterval = 30
    ) async throws -> Response {
        guard let baseURL else { throw RemoteAPIError.notConfigured }
        var request = URLRequest(url: baseURL.appendingPathComponent(path))
        request.httpMethod = method
        request.timeoutInterval = timeoutInterval
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let body { request.httpBody = try JSONSerialization.data(withJSONObject: body) }
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw RemoteAPIError.invalidResponse }
        guard (200..<300).contains(http.statusCode) else {
            let detail = (try? JSONSerialization.jsonObject(with: data) as? [String: Any])?["detail"] as? String
            throw RemoteAPIError.server(status: http.statusCode, detail: detail ?? "服务器请求失败")
        }
        if Response.self == EmptyResponse.self, data.isEmpty { return EmptyResponse() as! Response }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return try decoder.decode(Response.self, from: data)
    }
}

private struct EmptyResponse: Codable {}
private struct SessionUpdateResponse: Decodable { let sessionId: String; let stage: String }

enum RemoteAPIError: LocalizedError {
    case notConfigured, invalidResponse, server(status: Int, detail: String)
    var errorDescription: String? {
        switch self {
        case .notConfigured: "尚未配置 API_BASE_URL，请在 Config.xcconfig 中填写 HTTPS 后端地址"
        case .invalidResponse: "服务器返回无效响应"
        case .server(_, let detail): detail
        }
    }
}

struct CardService {
    /// This catalogue is local, fixed, and uniformly sampled. Its guidance is a bounded
    /// *question-generation space*, not a meaning shown to the person or a route selector.
    /// A lens may only be used after `CardGuidanceMatcher` finds a concrete overlap with the
    /// person's own visual narrative and later real-life connection.
    private struct Definition {
        let title: String
        let imageName: String
        let guidance: CardReflectionGuidance
    }

    private let catalogue: [Definition] = [
        .init(title: "未定之步", imageName: "未定之步", guidance: guidance(
            "不确定时的谨慎保护与逐渐不行动之间",
            tender: ["还没有准备好不等于软弱", "信息不完整时犹豫可以是在保护自己"],
            fierce: ["是否有一个可以尝试而且可回退的小动作", "哪些不确定需要先被说清楚，而不是无限等待"],
            anchors: ["路", "脚", "石头", "雾", "包"],
            directions: ["不确定", "行动", "回避", "准备"],
            scaffolds: [
                scaffold([["脚", "脚下"], ["路", "前面"]], "你觉得脚下这一步和前面的路有什么不同，才让画面停在这里？"),
                scaffold([["脚", "脚下"], ["路", "前面"]], "画面里哪一点让这一步还没有继续往前？"),
            ]
        )),
        .init(title: "暂放之处", imageName: "暂放之处", guidance: guidance(
            "必要恢复与长期停滞之间",
            tender: ["休息可能是在恢复，而不是懒惰", "过度消耗后暂时停下有它的原因"],
            fierce: ["这次停下更像恢复，还是已经让重新开始更难", "怎样用一个小而不苛刻的动作重新接上事情"],
            anchors: ["椅子", "鞋", "水", "地图", "路"],
            directions: ["休息", "恢复", "停滞", "开始"],
            scaffolds: [
                scaffold([["鞋"]], "你觉得这些鞋为什么会被放在这里？"),
                scaffold([["椅子", "鞋", "路"]], "只看画面的话，这次停下来以后，接下来可能会发生什么？"),
            ]
        )),
        .init(title: "借来的重量", imageName: "借来的重量", guidance: guidance(
            "自己的责任与他人的期待、情绪或任务之间",
            tender: ["替别人多承担一些不等于必须承担全部", "疲惫不说明能力不够"],
            fierce: ["哪些重量确实属于自己，哪些是习惯接过来的", "是否需要请求分担或重新分配"],
            anchors: ["包", "重量", "绳子", "推车", "岔路"],
            directions: ["责任", "边界", "分担", "帮助"],
            scaffolds: [
                scaffold([["包"]], "你觉得这些包为什么会以现在这样的方式放着？"),
                scaffold([["包", "重量"]], "画面里的这些重量接下来可能会被怎样处理？"),
            ]
        )),
        .init(title: "风中的灯", imageName: "风中的灯", guidance: guidance(
            "承认外部限制与寻找仍可控制的小部分之间",
            tender: ["环境和时机确实会让人难以维持稳定", "受影响不等于没有努力"],
            fierce: ["风还在时，什么小保护或支持是可用的", "哪些部分可以调整，哪些需要承认暂时无法控制"],
            anchors: ["灯", "风", "火", "玻璃", "树枝"],
            directions: ["限制", "保护", "控制", "支持"],
            scaffolds: [
                scaffold([["灯"]], "你觉得画面里的灯接下来会发生什么？"),
                scaffold([["灯"], ["风", "火", "玻璃", "树枝"]], "画面里哪一部分最可能改变这盏灯现在的状态？"),
            ]
        )),
        .init(title: "半开的门", imageName: "半开的门", guidance: guidance(
            "保护性的边界与回避必要沟通之间的张力",
            tender: ["保持距离可能是在保护安全、精力或尊严", "拒绝不等于冷漠或自私", "还没准备好进入对话是可以的"],
            fierce: ["是否需要更明确地表达边界", "沉默是否让关系持续悬而未决", "是否有一段需要回应或面对的对话"],
            anchors: ["门", "门把手", "室内", "室外", "身影"],
            directions: ["边界", "回避", "沟通", "保护"],
            scaffolds: [
                scaffold([["门"]], "你觉得这扇门接下来可能会被怎样处理？"),
                scaffold([["门"], ["门把手", "室内", "室外", "身影"]], "画面里什么让这扇门停在了现在这个位置？"),
            ],
            prohibited: ["你在逃避", "你应该重新打开这扇门", "门外的人代表某个具体的人", "这张牌说明你害怕亲密关系"]
        )),
        .init(title: "裂痕与器皿", imageName: "裂痕与器皿", guidance: guidance(
            "一次错误与对整个自我的否定之间",
            tender: ["做错一件事不等于整个人失败", "羞愧可以被看见，而不必替代事实"],
            fierce: ["这道具体裂痕造成了什么影响", "哪些影响需要承认、说明或修补"],
            anchors: ["碗", "裂缝", "水", "手", "布"],
            directions: ["羞愧", "责任", "修复", "自我评价"],
            scaffolds: [
                scaffold([["裂缝", "裂痕"]], "你觉得这条裂缝接下来可能会发生什么变化？"),
                scaffold([["碗", "器皿"], ["裂缝", "裂痕", "水", "手", "布"]], "画面里哪一点会影响这个器皿接下来怎样被处理？"),
            ]
        )),
        .init(title: "未寄出的信", imageName: "未寄出的信", guidance: guidance(
            "等待合适时机与延迟必要沟通之间",
            tender: ["害怕被误解或拒绝会让开口变难", "还没准备好说清楚不等于不在乎"],
            fierce: ["是否有一句具体的话需要回应、解释或道歉", "怎样在保护自己时说得更清楚"],
            anchors: ["信", "纸", "笔", "信封", "邮筒"],
            directions: ["沟通", "修复", "边界", "回避"],
            scaffolds: [
                scaffold([["信", "信封"]], "你觉得这封信为什么还停在这里，没有被寄出去？"),
                scaffold([["信", "信封", "纸"]], "只看画面的话，这封信接下来可能会被怎样处理？"),
            ]
        )),
        .init(title: "反复的脚印", imageName: "反复的脚印", guidance: guidance(
            "曾有保护作用的模式与它现在代价之间",
            tender: ["重复的做法往往曾帮助人暂时避开压力", "它出现不只因为不够自律"],
            fierce: ["这个循环现在带来了什么代价", "哪里可以试一个不同的小环节"],
            anchors: ["脚印", "圆圈", "路", "岔口", "人"],
            directions: ["模式", "回避", "改变", "安全"],
            scaffolds: [
                scaffold([["脚印"]], "你觉得这串脚印为什么又绕回了这里？"),
                scaffold([["脚印"], ["路", "岔口", "圆圈"]], "画面里的脚印接下来可能会往哪里延伸？"),
            ]
        )),
        .init(title: "松开的结", imageName: "松开的结", guidance: guidance(
            "守护承诺与松开持续伤害的连接之间",
            tender: ["放下不再适合的东西可能会有失落", "不再坚持不必等同于失败"],
            fierce: ["哪些承诺仍想保留，哪些需要重新决定", "是否需要主动松开一段消耗性的连接"],
            anchors: ["结", "绳子", "手", "剪刀", "线"],
            directions: ["放下", "边界", "失落", "选择"],
            scaffolds: [
                scaffold([["结"]], "你觉得这个结接下来可能会发生什么变化？"),
                scaffold([["绳子", "线"], ["结", "手", "剪刀"]], "画面里哪一点会影响这根绳子接下来怎样被处理？"),
            ]
        )),
        .init(title: "可移动的一块", imageName: "可移动的一块", guidance: guidance(
            "整体难题与一个实际可移动的小部分之间",
            tender: ["暂时解决不了全部不说明无能", "大问题让人难以开始是可以理解的"],
            fierce: ["哪一小块是真的可以试着移动的", "怎样用可验证的一步代替一次解决全部"],
            anchors: ["石头", "墙", "手", "路", "缺口"],
            directions: ["行动", "能力", "完美主义", "解决问题"],
            scaffolds: [
                scaffold([["石头", "石块"], ["移动", "挪开", "搬开"]], "如果这块石头被挪开，画面里哪一部分可能先发生变化？"),
                scaffold([["石头", "石块"], ["手"]], "你觉得他为什么会先从这一块开始？"),
            ]
        )),
        .init(title: "可用之手", imageName: "可用之手", guidance: guidance(
            "资源确实不足与忽略已有条件之间",
            tender: ["感到无助不等于真的没有能力", "缺少资源时需要被看见"],
            fierce: ["手边已有的技能、工具或帮助是什么", "怎样把需要说成一个具体请求"],
            anchors: ["手", "工具", "线", "纸", "木头"],
            directions: ["资源", "帮助", "行动", "不确定"],
            scaffolds: [
                scaffold([["手"], ["工具", "线", "纸", "木头"]], "你觉得这只手接下来最可能碰到或使用画面里的什么？"),
                scaffold([["手"]], "只看画面的话，这只手目前能做什么？"),
            ]
        )),
        .init(title: "两边的重量", imageName: "两边的重量", guidance: guidance(
            "自己与他人的需要、时间和责任分配之间",
            tender: ["在意他人并不表示自己不重要", "承受不均衡会让人疲惫"],
            fierce: ["哪些需要或责任需要重新分配", "是否有一边长期被忽略"],
            anchors: ["桌子", "两边", "重量", "物品", "中间"],
            directions: ["边界", "责任", "关系", "过载"],
            scaffolds: [
                scaffold([["两边", "左边", "右边"], ["桌子", "重量", "物品"]], "你觉得画面两边为什么会呈现现在这样的状态？"),
                scaffold([["两边", "左边", "右边"], ["重量", "物品"]], "如果画面里的东西继续变化，哪一边可能会先发生变化？"),
            ]
        )),
        .init(title: "被遮住的窗", imageName: "被遮住的窗", guidance: guidance(
            "已确认事实、个人解释与受情绪影响的判断之间",
            tender: ["在疲惫或情绪很强时看不清全貌并不奇怪", "暂时不确定不等于判断错误"],
            fierce: ["哪些是已经发生的事实，哪些是自己的推断", "还需要保留哪些未知"],
            anchors: ["窗", "雾", "雨", "布", "外面"],
            directions: ["判断", "自我评价", "不确定", "事实"],
            scaffolds: [
                scaffold([["窗"], ["雾", "雨", "布", "遮挡"]], "你觉得窗上的遮挡接下来可能会怎样变化？"),
                scaffold([["窗"], ["里面", "外面", "窗里", "窗外"]], "只看画面的话，窗里和窗外现在各能看见什么？"),
            ]
        )),
        .init(title: "留出的空间", imageName: "留出的空间", guidance: guidance(
            "照顾自己的空间与逐渐失去联系之间",
            tender: ["留出空间可能是为了恢复承受能力", "需要独处不等于不在乎关系"],
            fierce: ["这段距离的边界和期限是否需要说清楚", "空间是否已经变成难以回应的消失"],
            anchors: ["空位", "椅子", "桌子", "移动", "空间"],
            directions: ["边界", "保护", "沟通", "回避"],
            scaffolds: [
                scaffold([["空位", "空间"]], "你觉得这个空位为什么会被留出来？"),
                scaffold([["空间", "空位"], ["椅子", "桌子", "移动"]], "画面里的空间接下来可能会被怎样使用？"),
            ]
        )),
        .init(title: "镜外的一面", imageName: "镜外的一面", guidance: guidance(
            "具体行为与狭窄、反复的自我定义之间",
            tender: ["一次表现或结果不能概括整个人", "看见不满意之处不必变成自我否定"],
            fierce: ["如果只看具体行为，哪一部分值得调整", "怎样避免让一个标准占满全部自我评价"],
            anchors: ["镜子", "倒影", "照片", "外面", "物品"],
            directions: ["羞愧", "自我评价", "改变", "责任"],
            scaffolds: [
                scaffold([["镜子", "镜"], ["里面", "外面", "倒影"]], "你觉得镜子里能看到的和镜子外面有什么不同？"),
                scaffold([["镜子", "镜"], ["倒影", "照片", "外面"]], "画面里哪一部分没有出现在镜子里？"),
            ]
        )),
        .init(title: "同一场雨", imageName: "同一场雨", guidance: guidance(
            "共同人性与不淡化真实影响之间",
            tender: ["遇到困难不是个人缺陷", "有人同行或愿意帮助可以被看见"],
            fierce: ["共同经历不能代替对具体影响的处理", "是否需要向谁说明、请求或修复"],
            anchors: ["雨", "伞", "人", "屋檐", "雨具"],
            directions: ["共同感", "帮助", "责任", "连接"],
            scaffolds: [
                scaffold([["雨"], ["人", "伞", "屋檐", "雨具"]], "你觉得画面里的人在这场雨里各自在做什么？"),
                scaffold([["雨"], ["人", "伞", "屋檐", "雨具"]], "只看画面的话，这场雨接下来会怎样影响他们？"),
            ]
        )),
        .init(title: "退潮之后", imageName: "退潮之后", guidance: guidance(
            "先恢复与查看、处理冲突遗留之间",
            tender: ["情绪过去后先缓一缓可以是在保护自己", "没有立刻处理不一定是不负责"],
            fierce: ["平静后是否有后果需要清理、说明或修复", "什么时间点比较适合再回看"],
            anchors: ["潮水", "沙滩", "遗留物", "篮子", "海"],
            directions: ["恢复", "修复", "责任", "沟通"],
            scaffolds: [
                scaffold([["潮水", "退潮"], ["沙滩", "海", "遗留物", "篮子"]], "你觉得潮水退下以后，沙滩上哪一部分会先被注意到？"),
                scaffold([["遗留物", "留下", "篮子", "沙滩"]], "画面里留下来的东西接下来可能会被怎样处理？"),
            ]
        )),
        .init(title: "未完成的桥", imageName: "未完成的桥", guidance: guidance(
            "共同修复关系与单方反复搭桥之间",
            tender: ["关系修复不该只由一个人承担", "不能独自完成一座桥不代表不够努力"],
            fierce: ["自己愿意承担的是哪一块具体部分", "对方是否也有回应或边界需要被看见"],
            anchors: ["桥", "两岸", "木板", "河", "对面"],
            directions: ["关系", "修复", "边界", "责任"],
            scaffolds: [
                scaffold([["桥"]], "你觉得这座桥现在为什么停在这里？"),
                scaffold([["桥"], ["木板", "两岸", "河", "对面"]], "只看画面的话，要让这座桥继续，哪一部分可能先发生变化？"),
            ]
        )),
        .init(title: "重新摆放", imageName: "重新摆放", guidance: guidance(
            "适应现实与保留不再适合的旧安排之间",
            tender: ["计划改变不等于没有纪律", "能力和优先级变化值得被纳入安排"],
            fierce: ["哪些安排需要删减、调整或重新排序", "是否还在保留一个已不适合的要求"],
            anchors: ["桌子", "盒子", "物品", "空位", "摆放"],
            directions: ["计划", "改变", "优先级", "限制"],
            scaffolds: [
                scaffold([["东西", "物品", "盒子"], ["桌子", "位置", "摆放"]], "你觉得这些东西为什么会被重新放到现在的位置？"),
                scaffold([["东西", "物品", "盒子"], ["移动", "摆放", "空位"]], "画面里哪件东西接下来最可能被再次移动？"),
            ]
        )),
        .init(title: "仍亮着的窗", imageName: "仍亮着的窗", guidance: guidance(
            "独自承受与低风险地获得支持之间",
            tender: ["不知道怎样求助不等于必须独自承担", "想保持私密和自主是可以理解的"],
            fierce: ["是否有一个低风险的具体求助对象或方式", "怎样说明需要，同时保留自己的边界"],
            anchors: ["窗", "夜", "灯", "房子", "电话"],
            directions: ["帮助", "孤立", "沟通", "保护"],
            scaffolds: [
                scaffold([["窗"], ["灯", "亮", "夜", "房子"]], "你觉得这扇还亮着的窗和周围有什么不同？"),
                scaffold([["窗"], ["灯", "亮"]], "只看画面的话，这扇窗里的灯接下来可能会怎样？"),
            ]
        )),
        .init(title: "递出的手", imageName: "递出的手", guidance: guidance(
            "接受帮助与清楚说明自己需要之间",
            tender: ["接受支持不等于能力不足", "担心失去控制或欠人情是可以理解的"],
            fierce: ["能否说清楚想接受什么、不想接受什么", "怎样在求助时保留自主和边界"],
            anchors: ["手", "递", "物品", "距离", "接住"],
            directions: ["帮助", "边界", "沟通", "自主"],
            scaffolds: [
                scaffold([["手"], ["递", "递出", "物品"]], "你觉得这只递出的手在等画面里的什么回应？"),
                scaffold([["手"], ["递", "递出", "物品"]], "只看画面的话，这只手递出的东西接下来可能会怎样？"),
            ]
        )),
        .init(title: "留有余地的路", imageName: "留有余地的路", guidance: guidance(
            "保留调整余地与无限延迟之间",
            tender: ["可以调整的开始更容易持续", "不必一次把未来全部决定好"],
            fierce: ["怎样给下一步设一个小而可判断的边界", "留余地是否已经变成无限推迟"],
            anchors: ["路", "岔口", "平台", "转弯", "起点"],
            directions: ["行动", "改变", "弹性", "回避"],
            scaffolds: [
                scaffold([["路"], ["转弯", "岔口", "平台", "起点"]], "你觉得这条路为什么在这里留出了转弯或停下的位置？"),
                scaffold([["路"], ["转弯", "岔口", "平台", "起点"]], "只看画面的话，沿着这条路继续以后可能会发生什么？"),
            ]
        )),
    ]

    /// Supplementary self-compassion guidance from the 22-card design document. It remains
    /// separate from the original core-tension/tender/fierce catalogue so those semantics and
    /// the existing visual-overlap matcher cannot be changed accidentally.
    private static let selfCompassionSupplements: [String: CardSelfCompassionGuidance] = [
        "未定之步": selfCompassion(
            primary: .mindfulness,
            secondary: [.selfKindness, .commonHumanity],
            kindness: ["犹豫、缺少把握或害怕出错，不等于软弱、懒惰或没有能力"],
            humanity: ["只有当用户主动比较“别人都能开始、只有我不行”时，才可轻触信息不足时犹豫是常见处境"],
            mindfulness: ["分开真正缺少的信息、担心的结果，以及尚未发生也未经证实的预测"],
            question: "目前哪些部分是真的还不清楚，哪些部分是你担心可能发生、但尚未发生的？",
            activation: "用户把脚、雾、踏脚石或未完成的路联系到犹豫、开始困难或选择不确定时"
        ),
        "暂放之处": selfCompassion(
            primary: .selfKindness,
            secondary: [.mindfulness, .commonHumanity],
            kindness: ["疲惫和休息不自动等于懒惰，身体与情绪的承受能力需要被纳入理解"],
            humanity: ["只有用户谈到失败、失望或长期压力后的孤立感时，才可承认人需要恢复是共同处境"],
            mindfulness: ["观察停下后的实际作用：更有恢复，还是更焦虑、更回避或更难重新开始"],
            question: "这段停下来之后，你感到更有恢复，还是更难重新靠近原来的事情？",
            activation: "用户把长椅、鞋、地图或道路联系到疲惫、暂停或延迟时"
        ),
        "借来的重量": selfCompassion(
            primary: .commonHumanity,
            secondary: [.selfKindness, .mindfulness],
            kindness: ["承担过多后的疲惫、愤怒或无力不等于能力不足，也不必靠无限承担证明自己"],
            humanity: ["责任常存在于关系、团队和系统中，可以包含合理分工、相互依赖和共同承担"],
            mindfulness: ["把重量分成自己的、别人的、共同的，以及暂时没有人承担的部分"],
            question: "如果把这些重量分开看，哪些确实属于你的职责，哪些是别人交过来或你习惯接下的？",
            activation: "用户把包、重量、推车或岔路联系到过度承担、替别人完成任务或难以求助时"
        ),
        "风中的灯": selfCompassion(
            primary: .mindfulness,
            secondary: [.selfKindness, .commonHumanity],
            kindness: ["外部条件确实会增加难度，受影响不等于没有努力或存在个人缺陷"],
            humanity: ["只有用户出现“只有我维持不住”的比较时，才可自然承认人在持续外部压力下都会受影响"],
            mindfulness: ["分开不可控制的风、能够调整的保护，以及这盏灯是否仍值得继续守护"],
            question: "现在更像是风太大，还是已有的保护还不够？其中哪一部分是你能调整的？",
            activation: "用户把风、灯、火或遮挡物联系到外部压力、保护或有限控制时"
        ),
        "半开的门": selfCompassion(
            primary: .selfKindness,
            secondary: [.mindfulness, .commonHumanity],
            kindness: ["保持距离、拒绝或暂时退出，不自动等于冷漠、自私或没有能力维持关系"],
            humanity: ["靠近、退开和设立边界都是关系中的人类需要，健康联系不要求始终开放和立即回应"],
            mindfulness: ["分清正在关闭的是某个请求、一次互动、一段时间，还是整段关系"],
            question: "你想保护的具体是什么？同时，有没有一句需要说清楚、但还停在门口的话？",
            activation: "用户把门、门把手、内外空间或身影联系到边界、回避或未完成沟通时"
        ),
        "裂痕与器皿": selfCompassion(
            primary: .selfKindness,
            secondary: [.mindfulness, .commonHumanity],
            kindness: ["一次错误或表现不等于整个自我失败，可以承认行为而不把羞愧扩成整个人的结论"],
            humanity: ["犯错、判断失误或无意造成影响是人类经验的一部分，也不取消具体修复"],
            mindfulness: ["分开具体裂痕、全局自我评价和目前还不知道的影响"],
            question: "如果先不评价整个人，只看这道具体的“裂痕”，你认为哪些影响需要被承认或修补？",
            activation: "用户把裂缝、器皿、悬停的手或修补物联系到错误、羞愧或修复时"
        ),
        "未寄出的信": selfCompassion(
            primary: .mindfulness,
            secondary: [.selfKindness, .commonHumanity],
            kindness: ["在冲突、拒绝或不确定中不知道怎样表达是可以理解的，沉默也可能暂时起到保护作用"],
            humanity: ["艰难沟通、道歉、拒绝和表达边界是许多人都会遇到的关系处境"],
            mindfulness: ["区分尚未回应是因为需要时间、责任不清、害怕后果，还是正在回避必要沟通"],
            question: "这封还没寄出的信，缺少的是合适的话、合适的时机，还是面对回应的准备？",
            activation: "用户把信、信封、笔或等待的人联系到回应、解释、道歉或拒绝时"
        ),
        "反复的脚印": selfCompassion(
            primary: .mindfulness,
            secondary: [.selfKindness, .commonHumanity],
            kindness: ["反复出现的模式可能曾经提供过保护，看见它不需要得出“我没救了”或“我总会失败”"],
            humanity: ["人在压力下回到熟悉的应对方式很常见，改变过程也可能包含反复"],
            mindfulness: ["观察触发条件、短期保护作用和长期代价，而不是只给模式贴标签"],
            question: "这串脚印每次在什么情况下绕回原处？它当下帮你避开了什么，又留下了什么代价？",
            activation: "用户把绕回原处的脚印、道路或岔口联系到反复模式时"
        ),
        "松开的结": selfCompassion(
            primary: .selfKindness,
            secondary: [.mindfulness, .commonHumanity],
            kindness: ["放下目标、关系或期待不必等于失败，松开之前的失落也值得被承认"],
            humanity: ["关系、承诺和身份会改变，人无法永久保留所有连接"],
            mindfulness: ["区分重要承诺、持续伤害的连接，以及因为害怕失去而继续抓住的部分"],
            question: "你想保留的是这个结所代表的哪一部分？又有哪些勒得太紧的地方需要松一些？",
            activation: "用户把结、绳子、手或剪刀联系到放下、承诺、失落或边界时"
        ),
        "可移动的一块": selfCompassion(
            primary: .mindfulness,
            secondary: [.selfKindness, .commonHumanity],
            kindness: ["不能一次解决全部不等于没有能力，也不代表没有进展"],
            humanity: ["只有用户出现能力比较或“别人都能解决”时，才可承认复杂问题通常需要逐步处理"],
            mindfulness: ["分开不能移动、暂时不能移动，以及此刻确实可以移动的部分"],
            question: "如果不用一次解决全部，眼前哪一块是现在真的可以移动的？",
            activation: "用户把石块、墙、缺口或道路联系到整体难题和局部行动时"
        ),
        "可用之手": selfCompassion(
            primary: .selfKindness,
            secondary: [.commonHumanity, .mindfulness],
            kindness: ["暂时感到无力不等于没有能力，压力或害怕可能让已有资源变得不容易看见"],
            humanity: ["能力也包括使用工具、经验、合作和帮助，而不只是独立完成"],
            mindfulness: ["盘点实际存在的工具、技能、支持，以及仍然缺少的条件"],
            question: "现在手边已经有哪些工具、经验或人可以用？还真正缺少的是什么？",
            activation: "用户把手、工具、纸线或材料联系到资源、帮助或行动条件时"
        ),
        "两边的重量": selfCompassion(
            primary: .mindfulness,
            secondary: [.commonHumanity, .selfKindness],
            kindness: ["优先考虑他人可能来自善意或责任感，不自动等于软弱；长期不均衡带来的疲惫也需要被承认"],
            humanity: ["公平不一定意味着每一刻完全相等，也需要协商、互惠和共同调整"],
            mindfulness: ["观察谁承担什么、不均衡是否暂时、是否被看见、同意和调整"],
            question: "现在两边分别放着哪些需要和责任？这种不平衡是临时的，还是已经持续了一段时间？",
            activation: "用户把两边、重量、桌面或中间位置联系到责任分配和关系不均衡时"
        ),
        "被遮住的窗": selfCompassion(
            primary: .mindfulness,
            secondary: [.selfKindness, .commonHumanity],
            kindness: ["疲惫、羞愧或焦虑时看不清全貌，不等于不理性或没有判断能力"],
            humanity: ["只有用户把不清楚理解为“只有我有问题”时，才可轻触人在强烈情绪下视野都会变窄"],
            mindfulness: ["分开已经确认的事实、个人解释、情绪放大的部分和仍然未知的部分"],
            question: "如果把窗上的遮挡先分开，哪些是已经发生的事实，哪些是你的推测，还有哪些暂时看不清？",
            activation: "用户把窗、雾、雨或遮挡物联系到判断、自我评价或不确定时"
        ),
        "留出的空间": selfCompassion(
            primary: .selfKindness,
            secondary: [.mindfulness, .commonHumanity],
            kindness: ["时间、精力和私人空间是合理需要，不必靠随时可用来证明自己的价值"],
            humanity: ["人的注意力和情绪承受能力有限，关系既需要空间也需要沟通"],
            mindfulness: ["区分有意说明的边界和突然消失，并观察这段空间实际用来做什么"],
            question: "这段空间现在是在帮助你恢复，还是也让某些需要说明的事情一直悬着？",
            activation: "用户把空位、椅子、桌子或移动出的空间联系到边界、保护或消失时"
        ),
        "镜外的一面": selfCompassion(
            primary: .selfKindness,
            secondary: [.mindfulness, .commonHumanity],
            kindness: ["一个结果、行为或评价不等于完整的自己，可以反思具体行为而不作人格判决"],
            humanity: ["只有用户出现比较或“只有我这么差”时，才可自然承认不完美表现并非个人孤例"],
            mindfulness: ["分开镜中可见的部分、被遗漏的事实，以及证据与全局标签"],
            question: "镜子里现在只留下了哪一部分？还有哪些与这件事有关的事实没有被照进去？",
            activation: "用户把镜子、倒影、照片或镜外物体联系到羞愧和自我评价时"
        ),
        "同一场雨": selfCompassion(
            primary: .commonHumanity,
            secondary: [.selfKindness, .mindfulness],
            kindness: ["遇到困难、犯错或需要帮助不等于存在个人缺陷"],
            humanity: ["不同人的触发因素和痛苦程度不同，但不完美、失望、限制和需要支持是共同的人类经验"],
            mindfulness: ["共同性不能抹平具体差异和影响，同时容纳“我并不孤单”和“我的处境有其特殊性”"],
            question: "看见大家都在同一场雨里，对你来说更像减少了孤立感，还是让你的具体困难被忽略了？",
            activation: "用户把雨、不同应对、递出的雨具或共同天气联系到孤立、比较或共同人性时"
        ),
        "退潮之后": selfCompassion(
            primary: .mindfulness,
            secondary: [.selfKindness, .commonHumanity],
            kindness: ["强烈情绪中暂时离开、停止或保护自己是可以理解的"],
            humanity: ["冲突中反应不完整、平静后再处理遗留影响，是常见但仍需具体面对的关系过程"],
            mindfulness: ["情绪退去后再观察事实、影响和仍未处理的部分"],
            question: "等情绪像潮水一样退下一些后，沙滩上还留下了哪些需要处理的具体东西？",
            activation: "用户把潮水、沙滩、遗留物或篮子联系到恢复、冲突后果或修复时"
        ),
        "未完成的桥": selfCompassion(
            primary: .commonHumanity,
            secondary: [.mindfulness, .selfKindness],
            kindness: ["一段关系尚未修复，不一定说明自己努力不足或不值得被回应"],
            humanity: ["修复、信任和合作通常需要双方参与，一个人无法控制整座桥是否完成"],
            mindfulness: ["分开自己能够铺的一块、对方的部分，以及目前未知能否连接的部分"],
            question: "如果这座桥需要两边一起完成，你愿意铺的是哪一块？哪些部分并不由你单独决定？",
            activation: "用户把桥、两岸、木板或对面联系到关系修复、边界或共同责任时"
        ),
        "重新摆放": selfCompassion(
            primary: .mindfulness,
            secondary: [.selfKindness, .commonHumanity],
            kindness: ["调整计划、降低目标或重分配资源不等于没有纪律或失败"],
            humanity: ["只有用户出现能力或进度比较时，才可承认人的承受能力和优先级会随情境改变"],
            mindfulness: ["分清真正重要、可以暂放和当前无法同时保留的要求"],
            question: "现在最需要保留的是什么？哪些安排可以先移开、缩小或重新排序？",
            activation: "用户把桌面、盒子、物品或空位联系到计划、优先级和现实限制时"
        ),
        "仍亮着的窗": selfCompassion(
            primary: .commonHumanity,
            secondary: [.selfKindness, .mindfulness],
            kindness: ["不知道怎样求助、担心打扰或被拒绝，不等于不值得获得支持"],
            humanity: ["依赖、支持和被看见是人的需要，保持自主不等于必须独自承担"],
            mindfulness: ["分开“不会有人帮”的预测、过去的经验和可以尝试的低风险请求"],
            question: "如果只试一个很小、风险较低的求助，你希望那扇亮着的窗能提供什么？",
            activation: "用户把窗、夜、灯、房子或联络方式联系到孤立、求助和支持时"
        ),
        "递出的手": selfCompassion(
            primary: .commonHumanity,
            secondary: [.selfKindness, .mindfulness],
            kindness: ["接受帮助不等于能力不足、软弱或欠下一笔必须偿还的人情"],
            humanity: ["给予和接受支持都是相互依赖的一部分"],
            mindfulness: ["分清对方实际递出的是什么、自己真正需要什么，以及希望保留的边界"],
            question: "这只手递来的东西里，哪些是你愿意接住的，哪些需要先说清楚边界？",
            activation: "用户把递出的手、物品、距离或接住的动作联系到帮助、边界和自主时"
        ),
        "留有余地的路": selfCompassion(
            primary: .selfKindness,
            secondary: [.mindfulness, .commonHumanity],
            kindness: ["改变不必一次完成，也不必保证永不反复；调整和返回不自动等于失败"],
            humanity: ["只有用户比较“别人能坚持、只有我反复”时，才可承认可持续改变通常包含试验和调整"],
            mindfulness: ["分开有边界的调整余地和无限延迟，并明确可调整的时间、范围或判断标准"],
            question: "怎样为下一步留一点调整空间，同时也让自己知道什么时候需要重新决定？",
            activation: "用户把路、岔口、平台、转弯或起点联系到改变、弹性或延迟时"
        ),
    ]

    var allCards: [ReflectionCard] {
        catalogue.enumerated().map { index, definition in
            let guidance = definition.guidance
            let supplementedGuidance = CardReflectionGuidance(
                coreTension: guidance.coreTension,
                tenderLenses: guidance.tenderLenses,
                fierceLenses: guidance.fierceLenses,
                visualAnchors: guidance.visualAnchors,
                possibleDirections: guidance.possibleDirections,
                prohibitedClaims: guidance.prohibitedClaims,
                selfCompassion: Self.selfCompassionSupplements[definition.title],
                visualScaffolds: guidance.visualScaffolds
            )
            return ReflectionCard(
                id: index,
                neutralLabel: String(format: "图像卡 %02d", index + 1),
                title: definition.title,
                imageName: definition.imageName,
                reflectiveThemes: guidance.coreTension,
                internalGuidance: supplementedGuidance
            )
        }
    }

    func draw() -> ReflectionCard {
        // `allCards` is non-empty by construction; the fallback only protects a malformed future
        // catalogue without allowing route, emotion, or tracking data to affect selection.
        allCards.randomElement() ?? ReflectionCard(
            id: 0,
            neutralLabel: "图像卡 01",
            title: "未定之步",
            imageName: "未定之步",
            reflectiveThemes: "不确定时的谨慎保护与逐渐不行动之间"
        )
    }

    private static func guidance(
        _ coreTension: String,
        tender: [String],
        fierce: [String],
        anchors: [String],
        directions: [String],
        scaffolds: [CardVisualScaffold] = [],
        prohibited: [String] = []
    ) -> CardReflectionGuidance {
        CardReflectionGuidance(
            coreTension: coreTension,
            tenderLenses: tender,
            fierceLenses: fierce,
            visualAnchors: anchors,
            possibleDirections: directions,
            prohibitedClaims: [
                "不要从画面推断人格或心理状态",
                "不要把画中人物等同于用户或特定他人",
                "不要把候选方向说成结论",
                "不要用牌义覆盖用户自己的解释",
            ] + prohibited,
            visualScaffolds: scaffolds
        )
    }

    /// The question can only be used after every group has appeared in the person's own image
    /// narrative. `AppServices` owns these card-specific image affordances; the view model only
    /// owns when one may be used and how many attempts are allowed.
    private static func scaffold(
        _ requiredAnchorGroups: [[String]],
        _ question: String
    ) -> CardVisualScaffold {
        CardVisualScaffold(
            requiredAnchorGroups: requiredAnchorGroups,
            question: question
        )
    }

    private static func selfCompassion(
        primary: SelfCompassionDimension,
        secondary: [SelfCompassionDimension],
        kindness: [String],
        humanity: [String],
        mindfulness: [String],
        question: String,
        activation: String
    ) -> CardSelfCompassionGuidance {
        CardSelfCompassionGuidance(
            primaryDimension: primary,
            secondaryDimensions: secondary,
            selfKindnessCandidates: kindness,
            commonHumanityCandidates: humanity,
            mindfulnessCandidates: mindfulness,
            candidateQuestion: question,
            activationHint: activation
        )
    }
}

/// The overlap is computed locally so a model never gets to select a lens, a card, or a
/// reflection-state transition. Guidance becomes available only when three sides meet:
/// a user-grounded image relation, a user-grounded reality relation, and one relation concept
/// contained in this card's bounded guidance catalogue. Objects, titles, and life topics alone
/// can never activate card meaning.
struct CardGuidanceMatcher {
    func match(
        card: ReflectionCard,
        userImageNarrative: String,
        semanticRelations: [SemanticRelation]
    ) -> CardGuidanceMatch? {
        guard let guidance = card.internalGuidance else { return nil }
        let image = comparable(userImageNarrative)
        let anchors = guidance.visualAnchors.filter { anchor in
            let normalized = comparable(anchor)
            // Single-character Chinese anchors such as 门、灯、路 are meaningful in the
            // card-specific catalogue. The old > 1 guard silently disabled guidance for many
            // otherwise valid image descriptions.
            return !normalized.isEmpty && image.contains(normalized)
        }
        guard !anchors.isEmpty else { return nil }

        let imageRelations = groundedRelations(.imageStructure, from: semanticRelations)
        let realityRelations = groundedRelations(.realityStructure, from: semanticRelations)
        guard !imageRelations.isEmpty, !realityRelations.isEmpty else { return nil }
        let allowedConcepts = guidanceConcepts(guidance)
        guard !allowedConcepts.isEmpty else { return nil }

        var best: (
            image: SemanticRelation,
            reality: SemanticRelation,
            concepts: Set<SemanticConcept>,
            directions: [String]
        )?
        for imageRelation in imageRelations {
            let imageConcepts = Set(imageRelation.concepts)
            for realityRelation in realityRelations {
                let sharedConcepts = imageConcepts
                    .intersection(realityRelation.concepts)
                    .intersection(allowedConcepts)
                let directions = directionLabels(
                    for: sharedConcepts,
                    preferred: guidance.possibleDirections
                )
                guard !directions.isEmpty else { continue }
                if best == nil || directions.count > best!.directions.count {
                    best = (imageRelation, realityRelation, sharedConcepts, directions)
                }
            }
        }
        guard let best else { return nil }
        let tenderLensID = selectedLensID(
            cardID: card.id,
            kind: "tender",
            candidates: guidance.tenderLenses,
            matchedConcepts: best.concepts
        )
        let fierceLensID = selectedLensID(
            cardID: card.id,
            kind: "fierce",
            candidates: guidance.fierceLenses,
            matchedConcepts: best.concepts
        )
        let selfCompassionCandidateID = selectedSelfCompassionCandidateID(
            cardID: card.id,
            guidance: guidance.selfCompassion,
            matchedConcepts: best.concepts
        )
        return CardGuidanceMatch(
            matchedVisualAnchors: anchors,
            candidateDirections: best.directions,
            imageRelation: relationSummary(best.image),
            realityRelation: relationSummary(best.reality),
            matchedConcepts: Array(best.concepts).sorted { $0.rawValue < $1.rawValue },
            selectedTenderLensID: tenderLensID,
            selectedFierceLensID: fierceLensID,
            selectedSelfCompassionCandidateID: selfCompassionCandidateID
        )
    }

    /// Select one catalogue entry locally. Shared relation concepts decide which entry is the
    /// closest fit; catalogue order is only a deterministic tie-breaker. The resulting stable ID
    /// is persisted in the session so a later model call cannot choose or blend other lenses.
    private func selectedLensID(
        cardID: Int,
        kind: String,
        candidates: [String],
        matchedConcepts: Set<SemanticConcept>
    ) -> String? {
        guard !candidates.isEmpty else { return nil }
        let ranked = candidates.enumerated().map { index, text in
            (
                index: index,
                score: concepts(in: text).intersection(matchedConcepts).count
            )
        }
        let selected = ranked.max {
            if $0.score == $1.score { return $0.index > $1.index }
            return $0.score < $1.score
        }?.index ?? 0
        return "card:\(cardID):\(kind):\(selected)"
    }

    private func selectedSelfCompassionCandidateID(
        cardID: Int,
        guidance: CardSelfCompassionGuidance?,
        matchedConcepts: Set<SemanticConcept>
    ) -> String? {
        guard let guidance else { return nil }
        let orderedDimensions = [guidance.primaryDimension] +
            guidance.secondaryDimensions.filter { $0 != guidance.primaryDimension }
        let candidates: [(dimension: SelfCompassionDimension, index: Int, text: String)] =
            orderedDimensions.flatMap { dimension in
                selfCompassionCandidates(for: dimension, guidance: guidance)
                    .enumerated()
                    .map {
                        (dimension: dimension, index: $0.offset, text: $0.element)
                    }
            }
        guard !candidates.isEmpty else { return nil }
        let ranked = candidates.enumerated().map { order, candidate in
            (
                order: order,
                candidate: candidate,
                score: concepts(in: candidate.text).intersection(matchedConcepts).count
            )
        }
        let selected = ranked.max {
            if $0.score == $1.score { return $0.order > $1.order }
            return $0.score < $1.score
        }?.candidate ?? candidates[0]
        return "card:\(cardID):self:\(selected.dimension.rawValue):\(selected.index)"
    }

    private func selfCompassionCandidates(
        for dimension: SelfCompassionDimension,
        guidance: CardSelfCompassionGuidance
    ) -> [String] {
        switch dimension {
        case .selfKindness: guidance.selfKindnessCandidates
        case .commonHumanity: guidance.commonHumanityCandidates
        case .mindfulness: guidance.mindfulnessCandidates
        }
    }

    private func groundedRelations(
        _ kind: SemanticRelationKind,
        from relations: [SemanticRelation]
    ) -> [SemanticRelation] {
        relations.filter {
            $0.kind == kind &&
            [.userStated, .userConfirmed].contains($0.status) &&
            $0.confidence >= 0.6 &&
            !$0.evidence.isEmpty &&
            !$0.source.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
            !$0.relation.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
            !$0.target.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
    }

    private func relationSummary(_ relation: SemanticRelation) -> String {
        "\(relation.source) \(relation.relation) \(relation.target)"
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func guidanceConcepts(_ guidance: CardReflectionGuidance) -> Set<SemanticConcept> {
        var concepts = Set(guidance.possibleDirections.compactMap { directionConcepts[$0] })
        let text = (
            [guidance.coreTension] + guidance.tenderLenses + guidance.fierceLenses
        ).joined(separator: "；")
        concepts.formUnion(self.concepts(in: text))
        return concepts
    }

    private func concepts(in text: String) -> Set<SemanticConcept> {
        var concepts = Set<SemanticConcept>()
        for (label, concept) in directionConcepts where text.contains(label) {
            concepts.insert(concept)
        }
        for (alias, concept) in relationalAliases where text.contains(alias) {
            concepts.insert(concept)
        }
        return concepts
    }

    private func directionLabels(
        for concepts: Set<SemanticConcept>,
        preferred: [String]
    ) -> [String] {
        var labels = preferred.filter {
            directionConcepts[$0].map(concepts.contains) == true
        }
        for concept in concepts.sorted(by: { $0.rawValue < $1.rawValue }) {
            guard !labels.contains(where: { directionConcepts[$0] == concept }) else { continue }
            if let label = directionConcepts.first(where: { $0.value == concept })?.key {
                labels.append(label)
            }
        }
        return labels
    }

    private func comparable(_ text: String) -> String {
        text.lowercased()
            .replacingOccurrences(of: " ", with: "")
            .replacingOccurrences(of: "，", with: "")
            .replacingOccurrences(of: "。", with: "")
            .replacingOccurrences(of: "、", with: "")
            .replacingOccurrences(of: "？", with: "")
            .replacingOccurrences(of: "！", with: "")
    }

    private let directionConcepts: [String: SemanticConcept] = [
        "不确定": .uncertainty, "行动": .action, "回避": .avoidance,
        "准备": .preparation, "休息": .rest, "恢复": .recovery,
        "停滞": .stagnation, "责任": .responsibility, "边界": .boundary,
        "分担": .sharing, "帮助": .support, "限制": .constraint,
        "保护": .protection, "控制": .control, "羞愧": .shame,
        "修复": .repair, "沟通": .communication, "模式": .pattern,
        "改变": .change, "安全": .safety, "放下": .lettingGo,
        "失落": .loss, "选择": .choice, "能力": .ability,
        "完美主义": .perfectionism, "解决问题": .problemSolving,
        "资源": .resources, "过载": .overload, "关系": .relationship,
        "判断": .judgment, "自我评价": .selfEvaluation, "事实": .facts,
        "共同感": .commonHumanity, "连接": .connection, "孤立": .isolation,
        "自主": .autonomy, "计划": .planning, "优先级": .priority,
        "弹性": .flexibility,
    ]

    /// Relation language in the catalogue is often phrased as a possibility rather than an
    /// ontology noun. These aliases inspect internal guidance only and remain scenario-neutral.
    private let relationalAliases: [(String, SemanticConcept)] = [
        ("可移动", .control), ("可以调整", .control), ("能够改变", .control),
        ("无法控制", .constraint), ("不能控制", .constraint),
        ("无法", .constraint), ("不能", .constraint),
        ("承担全部", .sharing), ("重新分配", .sharing),
        ("说清楚", .communication), ("回应", .communication),
        ("影响", .responsibility), ("修补", .repair),
        ("重新开始", .change), ("下一步", .action),
    ]
}

/// Validates an Analyzer-proposed response function before it can reach the Writer. The model may
/// choose a useful semantic direction, while Swift retains authority over evidence, permissions,
/// question count, card use, action, and workflow state.
struct ResponsePlanValidator {
    func validate(
        _ candidate: ResponsePlan?,
        analysis: ContextAnalysis,
        state: ReflectionState,
        workflowPhase: ReflectionWorkflowPhase,
        messages: [ChatMessage]
    ) -> ResponsePlan? {
        guard let plan = candidate?.validated,
              plan.confidence >= 0.55,
              !plan.focus.isEmpty,
              !plan.evidence.isEmpty,
              allowedFunctions(for: state, workflowPhase: workflowPhase).contains(plan.function)
        else {
            return nil
        }

        let transcript = comparable(
            messages
                .filter { $0.role == .user }
                .map(\.content)
                .joined(separator: " ")
        )
        let latestUserTurn = comparable(
            messages.last(where: { $0.role == .user })?.content ?? ""
        )
        guard plan.evidence.allSatisfy({
            let fragment = comparable($0)
            return fragment.count >= 2 && transcript.contains(fragment)
        }),
        plan.evidence.contains(where: {
            let fragment = comparable($0)
            return fragment.count >= 2 && latestUserTurn.contains(fragment)
        }) else {
            return nil
        }

        let grounded = analysis.validated.resolvedSemanticRelations.filter { relation in
            [.userStated, .userConfirmed].contains(relation.status) &&
                relation.confidence >= 0.6 &&
                !relation.evidence.isEmpty &&
                relation.evidence.allSatisfy {
                    let fragment = comparable($0)
                    return fragment.count >= 2 && transcript.contains(fragment)
                }
        }
        guard !plan.relationKinds.isEmpty,
              plan.relationKinds.allSatisfy({ kind in
                  grounded.contains { $0.kind == kind }
              }),
              functionEvidenceIsAllowed(plan.function, grounded: grounded)
        else {
            return nil
        }

        if plan.shouldAskQuestion == false,
           ![.synthesizeNarrative, .closeWithoutQuestion].contains(plan.function) {
            return nil
        }
        return plan
    }

    private func functionEvidenceIsAllowed(
        _ function: ResponseFunction,
        grounded: [SemanticRelation]
    ) -> Bool {
        let kinds = Set(grounded.map(\.kind))
        switch function {
        case .exploreLivedExperience:
            return kinds.contains(.eventExperience)
        case .clarifyPersonalMeaning:
            return !kinds.isDisjoint(with: [.selfEvaluation, .unmetNeed, .uncertainty])
        case .clarifyCircumstances:
            return !kinds.isDisjoint(
                with: [.conditionCapacity, .boundaryNeed, .unmetNeed, .uncertainty, .behaviorImpact]
            )
        case .synthesizeTenderUnderstanding, .deepenTenderUnderstanding:
            return !kinds.isEmpty
        case .contextualizeTracking:
            return !kinds.isDisjoint(with: [.conditionCapacity, .uncertainty])
        case .developImageRelation:
            return kinds.contains(.imageStructure)
        case .connectImageToReality:
            return kinds.contains(.imageStructure) && kinds.contains(.realityStructure)
        case .explorePerspectiveShift:
            return kinds.contains(.imageRealityMapping) || kinds.contains(.meaningShift)
        case .exploreAgencyBoundaryOrChange:
            return !kinds.isDisjoint(with: [.behaviorImpact, .boundaryNeed, .controllablePart])
        case .synthesizeNarrative, .confirmUnderstanding:
            return !kinds.isEmpty
        case .proposePractice:
            return !kinds.isDisjoint(with: [.behaviorImpact, .boundaryNeed, .controllablePart, .unmetNeed])
        case .closeWithoutQuestion:
            return kinds.contains(.uncertainty)
        }
    }

    func allowedFunctions(
        for state: ReflectionState,
        workflowPhase: ReflectionWorkflowPhase
    ) -> Set<ResponseFunction> {
        switch state {
        case .eventDisclosure, .emotionDisclosure, .bodilyResponse, .selfJudgment,
             .contextDisclosure:
            return [
                .exploreLivedExperience,
                .clarifyPersonalMeaning,
                .clarifyCircumstances,
                .synthesizeTenderUnderstanding,
                .closeWithoutQuestion,
            ]
        case .tenderGrounding, .tenderExploration:
            return [.deepenTenderUnderstanding, .confirmUnderstanding, .closeWithoutQuestion]
        case .trackingReview:
            return [.contextualizeTracking, .confirmUnderstanding, .closeWithoutQuestion]
        case .readinessCheck:
            return [.confirmUnderstanding, .deepenTenderUnderstanding, .closeWithoutQuestion]
        case .cardInterpretation:
            return [.developImageRelation, .closeWithoutQuestion]
        case .attributionReflection:
            switch workflowPhase {
            case .cardConnection:
                return [.connectImageToReality, .closeWithoutQuestion]
            case .cardMappingConfirmation:
                return [.confirmUnderstanding, .closeWithoutQuestion]
            case .candidCircumstances:
                return [.deepenTenderUnderstanding, .closeWithoutQuestion]
            case .cardMeaningShift:
                return [.explorePerspectiveShift, .closeWithoutQuestion]
            case .candidAgency:
                return [.exploreAgencyBoundaryOrChange, .closeWithoutQuestion]
            case .reflectionNarrativeConfirmation, .narrativeConfirmation:
                return [
                    .synthesizeNarrative, .confirmUnderstanding, .proposePractice,
                    .closeWithoutQuestion,
                ]
            case .optionalAction, .actionConfirmation:
                return [.proposePractice, .confirmUnderstanding, .closeWithoutQuestion]
            default:
                return [.confirmUnderstanding, .closeWithoutQuestion]
            }
        case .actionSelection:
            return [.proposePractice, .closeWithoutQuestion]
        case .summary:
            return [.synthesizeNarrative, .closeWithoutQuestion]
        case .welcome, .trackingPermission, .cardIntroduction, .completed, .safetySupport:
            return [.closeWithoutQuestion]
        }
    }

    /// Recovers only the conversational function when the Analyzer supplied valid semantic
    /// relations but omitted or malformed `responsePlan`. This remains domain-neutral: no topic,
    /// scenario word, or missing disclosure field decides the result. A recovered plan must still
    /// cite literal evidence from the latest user turn and pass the same phase/evidence validator
    /// as a model-authored plan.
    func recoverDisclosurePlan(
        analysis: ContextAnalysis,
        state: ReflectionState,
        workflowPhase: ReflectionWorkflowPhase,
        messages: [ChatMessage]
    ) -> ResponsePlan? {
        guard [
            ReflectionState.eventDisclosure,
            .emotionDisclosure,
            .bodilyResponse,
            .selfJudgment,
            .contextDisclosure,
        ].contains(state) else {
            return nil
        }

        let transcript = comparable(
            messages
                .filter { $0.role == .user }
                .map(\.content)
                .joined(separator: " ")
        )
        let latestUserTurn = comparable(
            messages.last(where: { $0.role == .user })?.content ?? ""
        )
        guard !latestUserTurn.isEmpty else { return nil }

        let grounded = analysis.validated.resolvedSemanticRelations.filter { relation in
            [.userStated, .userConfirmed].contains(relation.status) &&
                relation.confidence >= 0.6 &&
                !relation.evidence.isEmpty &&
                relation.evidence.allSatisfy {
                    let fragment = comparable($0)
                    return fragment.count >= 2 && transcript.contains(fragment)
                } &&
                relation.evidence.contains {
                    let fragment = comparable($0)
                    return fragment.count >= 2 && latestUserTurn.contains(fragment)
                }
        }

        // Recovery is intentionally narrower than normal model planning. An omitted plan must
        // not let an arbitrary condition/behavior relation redirect the whole disclosure. The
        // high-value exception is an explicit whole-self evaluation: ignoring it to collect a
        // missing emotion is exactly the conversational failure this compatibility path prevents.
        let priority: [(Set<SemanticRelationKind>, ResponseFunction, String)] = [
            (
                [.selfEvaluation],
                .clarifyPersonalMeaning,
                "clarify the concrete concern or personal meaning behind the user's self-evaluation"
            ),
        ]

        guard let (relation, function, questionIntent) = priority.lazy.compactMap({
            kinds, function, questionIntent -> (SemanticRelation, ResponseFunction, String)? in
            guard allowedFunctions(for: state, workflowPhase: workflowPhase).contains(function),
                  let relation = grounded.first(where: { kinds.contains($0.kind) }) else {
                return nil
            }
            return (relation, function, questionIntent)
        }).first else {
            return nil
        }

        let latestEvidence = relation.evidence.filter {
            latestUserTurn.contains(comparable($0))
        }
        let remainingEvidence = relation.evidence.filter {
            !latestEvidence.contains($0)
        }
        let evidence = Array((latestEvidence + remainingEvidence).prefix(3))
        let candidate = ResponsePlan(
            function: function,
            focus: "\(relation.source) \(relation.relation) \(relation.target)",
            evidence: evidence,
            relationKinds: [relation.kind],
            questionIntent: questionIntent,
            shouldAskQuestion: true,
            confidence: relation.confidence
        )
        return validate(
            candidate,
            analysis: analysis,
            state: state,
            workflowPhase: workflowPhase,
            messages: messages
        )
    }

    private func comparable(_ text: String) -> String {
        text.lowercased().filter { $0.isLetter || $0.isNumber }
    }
}

struct SafetyService {
    private let signals = ["自杀", "不想活", "结束生命", "伤害自己", "suicide", "kill myself", "self-harm"]
    func requiresInterrupt(_ text: String) -> Bool { signals.contains { text.localizedCaseInsensitiveContains($0) } }
}

/// Chooses the kind of optional practice from domain-neutral relations that Swift has already
/// verified against the user's transcript. It does not inspect topics, people, diagnoses, or
/// scenario words, and it never creates an action itself.
struct CompassionatePracticeResolver {
    func resolve(
        analysis: ContextAnalysis,
        groundedRelations: [SemanticRelation]
    ) -> CompassionatePracticeDirection {
        let behaviorImpacts = groundedRelations.filter { $0.kind == .behaviorImpact }
        let boundaryNeeds = groundedRelations.filter { $0.kind == .boundaryNeed }
        let controllableParts = groundedRelations.filter { $0.kind == .controllablePart }
        let capacityConditions = groundedRelations.filter { $0.kind == .conditionCapacity }
        let selfEvaluations = groundedRelations.filter { $0.kind == .selfEvaluation }
        let unmetNeeds = groundedRelations.filter { $0.kind == .unmetNeed }

        if behaviorImpacts.contains(where: {
            !Set($0.concepts).isDisjoint(
                with: Set<SemanticConcept>([.repair, .responsibility, .communication])
            )
        }) {
            return .repair
        }
        if !boundaryNeeds.isEmpty {
            return .protection
        }

        let currentBurdenIsHigh =
            analysis.distressLevel >= 2 ||
            analysis.selfAttackLevel >= 2 ||
            analysis.reflectiveCapacity <= 1
        let tenderSupportIsGrounded =
            !capacityConditions.isEmpty ||
            !selfEvaluations.isEmpty ||
            !unmetNeeds.isEmpty
        if currentBurdenIsHigh && tenderSupportIsGrounded {
            return .care
        }
        if !controllableParts.isEmpty || !behaviorImpacts.isEmpty {
            return .change
        }
        // No repair/change evidence does not mean that no practice is possible. When the
        // transcript still contains an evidence-backed burden, whole-self judgment, or unmet
        // need, a low-demand care practice is the non-blaming direction.
        if tenderSupportIsGrounded {
            return .care
        }
        return .noAction
    }
}

actor SessionStore {
    private let directory: URL
    init() {
        directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("ReflectionSessions", isDirectory: true)
    }
    func save(_ session: ReflectionSession) throws {
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        try JSONEncoder().encode(session).write(to: directory.appendingPathComponent("\(session.id.uuidString).json"), options: .atomic)
    }
    func delete(id: UUID) throws {
        let url = directory.appendingPathComponent("\(id.uuidString).json")
        if FileManager.default.fileExists(atPath: url.path) { try FileManager.default.removeItem(at: url) }
    }
    func deleteAll() throws {
        guard FileManager.default.fileExists(atPath: directory.path) else { return }
        try FileManager.default.removeItem(at: directory)
    }
}

struct TrackingSourceCandidate: Equatable {
    let bundleIdentifier: String
    let distinctDayCount: Int
    let sampleCount: Int
}

struct HealthSourcePriorityPolicy {
    func preferredBundleIdentifier(from candidates: [TrackingSourceCandidate]) -> String? {
        candidates.max { lhs, rhs in
            if lhs.distinctDayCount != rhs.distinctDayCount {
                return lhs.distinctDayCount < rhs.distinctDayCount
            }
            if lhs.sampleCount != rhs.sampleCount { return lhs.sampleCount < rhs.sampleCount }
            return lhs.bundleIdentifier > rhs.bundleIdentifier
        }?.bundleIdentifier
    }
}

actor HealthKitService {
    private let store = HKHealthStore()
    private let analyzer = DeterministicSelfTrackingAnalyzer()
    func requestAuthorization() async {
        guard HKHealthStore.isHealthDataAvailable(),
              let sleep = HKObjectType.categoryType(forIdentifier: .sleepAnalysis),
              let restingHeart = HKObjectType.quantityType(forIdentifier: .restingHeartRate),
              let hrv = HKObjectType.quantityType(forIdentifier: .heartRateVariabilitySDNN),
              let steps = HKObjectType.quantityType(forIdentifier: .stepCount) else { return }
        try? await store.requestAuthorization(toShare: [], read: [sleep, restingHeart, hrv, steps])
    }

    func fetch(referenceDate: Date) async -> [TrackingCue] {
        guard HKHealthStore.isHealthDataAvailable(),
              let sleep = HKObjectType.categoryType(forIdentifier: .sleepAnalysis),
              let restingHeart = HKObjectType.quantityType(forIdentifier: .restingHeartRate),
              let hrv = HKObjectType.quantityType(forIdentifier: .heartRateVariabilitySDNN),
              let steps = HKObjectType.quantityType(forIdentifier: .stepCount) else { return [] }
        let calendar = Calendar.current
        let referenceDay = calendar.startOfDay(for: referenceDate)
        let recentStart = calendar.date(byAdding: .day, value: -6, to: referenceDay) ?? referenceDay
        let rangeStart = calendar.date(byAdding: .day, value: -34, to: referenceDay) ?? recentStart
        let rangeEnd = calendar.date(byAdding: .day, value: 1, to: referenceDay) ?? referenceDate
        async let sleepSamples = samples(type: sleep, start: rangeStart, end: rangeEnd)
        async let heartSamples = samples(type: restingHeart, start: rangeStart, end: rangeEnd)
        async let hrvSamples = samples(type: hrv, start: rangeStart, end: rangeEnd)
        async let stepSamples = samples(type: steps, start: rangeStart, end: rangeEnd)
        let asleepValues: Set<Int> = [
            HKCategoryValueSleepAnalysis.asleepUnspecified.rawValue,
            HKCategoryValueSleepAnalysis.asleepCore.rawValue,
            HKCategoryValueSleepAnalysis.asleepDeep.rawValue,
            HKCategoryValueSleepAnalysis.asleepREM.rawValue
        ]
        let sleeps = preferredSourceSamples(
            await sleepSamples.compactMap { $0 as? HKCategorySample }.filter { asleepValues.contains($0.value) }
        )
        let hearts = preferredSourceSamples(await heartSamples.compactMap { $0 as? HKQuantitySample })
        let hrvs = preferredSourceSamples(await hrvSamples.compactMap { $0 as? HKQuantitySample })
        let stepValues = preferredSourceSamples(await stepSamples.compactMap { $0 as? HKQuantitySample })
        let historyDays = (0..<35).compactMap { calendar.date(byAdding: .day, value: $0, to: rangeStart) }
        var cues: [TrackingCue] = []
        var dataset = SelfTrackingDataset(dailyMetrics: [:], provenance: [:])

        let sleepGroups = Dictionary(grouping: sleeps) { calendar.startOfDay(for: $0.endDate) }
        let nightlyHistory = historyDays.map { day -> TrackingDataPoint in
            let night = sleepGroups[day] ?? []
            let hours = night.isEmpty ? nil : mergedDuration(of: night) / 3600
            return .init(date: day, value: hours, count: night.count)
        }
        let sleepTimingHistory = historyDays.map { day -> TrackingDataPoint in
            let night = sleepGroups[day] ?? []
            guard let onset = night.map(\.startDate).min() else {
                return .init(date: day, value: nil, count: 0)
            }
            // Store the first asleep interval rather than the sleep midpoint. This produces a
            // user-understandable “usual time of falling asleep” while the analyzer still handles
            // midnight with circular comparisons.
            let components = calendar.dateComponents([.hour, .minute], from: onset)
            let decimalHour = Double(components.hour ?? 0) + Double(components.minute ?? 0) / 60
            return .init(date: day, value: decimalHour, count: night.count)
        }
        let sleepWakeHistory = historyDays.map { day -> TrackingDataPoint in
            let night = sleepGroups[day] ?? []
            guard let wake = night.map(\.endDate).max() else {
                return .init(date: day, value: nil, count: 0)
            }
            let components = calendar.dateComponents([.hour, .minute], from: wake)
            let decimalHour = Double(components.hour ?? 0) + Double(components.minute ?? 0) / 60
            return .init(date: day, value: decimalHour, count: night.count)
        }
        let sleepContinuityHistory = historyDays.map { day -> TrackingDataPoint in
            let night = sleepGroups[day] ?? []
            guard let onset = night.map(\.startDate).min(),
                  let wake = night.map(\.endDate).max() else {
                return .init(date: day, value: nil, count: 0)
            }
            let elapsed = wake.timeIntervalSince(onset)
            guard elapsed > 0 else { return .init(date: day, value: nil, count: night.count) }
            // This is deliberately a record-continuity proxy: asleep intervals divided by their
            // first-to-last span. It is not a subjective sleep-quality score.
            return .init(
                date: day,
                value: min(max(mergedDuration(of: night) / elapsed, 0), 1),
                count: night.count
            )
        }
        let nightlyPoints = Array(nightlyHistory.suffix(7))
        let nightlyHours = nightlyPoints.compactMap(\.value)
        if !nightlyHours.isEmpty {
            let medianHours = TrackingStatistics.median(nightlyHours)
            cues.append(.init(
                source: .healthSleep,
                observation: "最近 7 天中有 \(nightlyHours.count) 晚睡眠记录，仍需结合个人历史和缺失记录理解。",
                metrics: .init(
                    periodStart: recentStart,
                    periodEnd: referenceDay,
                    summaryValue: medianHours,
                    unit: "小时/晚",
                    sampleCount: sleeps.count,
                    daily: nightlyPoints
                )
            ))
            dataset.dailyMetrics[.sleepDuration] = nightlyHistory
            dataset.provenance[.sleepDuration] = provenance(for: sleeps, sampleType: "sleepAnalysis")
            dataset.dailyMetrics[.sleepTiming] = sleepTimingHistory
            dataset.provenance[.sleepTiming] = provenance(for: sleeps, sampleType: "sleepAnalysisTiming")
            dataset.dailyMetrics[.sleepWakeTime] = sleepWakeHistory
            dataset.provenance[.sleepWakeTime] = provenance(for: sleeps, sampleType: "sleepAnalysisWakeTime")
            dataset.dailyMetrics[.sleepContinuity] = sleepContinuityHistory
            dataset.provenance[.sleepContinuity] = provenance(for: sleeps, sampleType: "sleepAnalysisRecordedContinuity")
        }

        let bpm = HKUnit.count().unitDivided(by: .minute())
        if let cue = quantityCue(
            source: .healthHeartRate,
            label: "最近 7 天静息心率",
            samples: hearts,
            unit: bpm,
            suffix: "bpm",
            days: historyDays,
            periodStart: recentStart,
            periodEnd: referenceDay
        ) {
            dataset.dailyMetrics[.restingHeartRate] = cue.metrics?.daily
            dataset.provenance[.restingHeartRate] = provenance(for: hearts, sampleType: "restingHeartRate")
            var recentCue = cue
            if let metrics = cue.metrics {
                recentCue.metrics = .init(
                    periodStart: recentStart, periodEnd: referenceDay,
                    summaryValue: TrackingStatistics.median(Array(metrics.daily.suffix(7)).compactMap(\.value)),
                    unit: metrics.unit, sampleCount: hearts.count, daily: Array(metrics.daily.suffix(7))
                )
            }
            cues.append(recentCue)
        }
        let milliseconds = HKUnit.secondUnit(with: .milli)
        if let cue = quantityCue(
            source: .healthHRV,
            label: "最近 7 天 HRV（SDNN）",
            samples: hrvs,
            unit: milliseconds,
            suffix: "ms",
            days: historyDays,
            periodStart: recentStart,
            periodEnd: referenceDay
        ) {
            dataset.dailyMetrics[.heartRateVariability] = cue.metrics?.daily
            dataset.provenance[.heartRateVariability] = provenance(for: hrvs, sampleType: "heartRateVariabilitySDNN")
            var recentCue = cue
            if let metrics = cue.metrics {
                recentCue.metrics = .init(
                    periodStart: recentStart, periodEnd: referenceDay,
                    summaryValue: TrackingStatistics.median(Array(metrics.daily.suffix(7)).compactMap(\.value)),
                    unit: metrics.unit, sampleCount: hrvs.count, daily: Array(metrics.daily.suffix(7))
                )
            }
            cues.append(recentCue)
        }
        let stepUnit = HKUnit.count()
        if let cue = quantityCue(
            source: .healthSteps,
            label: "最近 7 天步数记录",
            samples: stepValues,
            unit: stepUnit,
            suffix: "步",
            days: historyDays,
            periodStart: recentStart,
            periodEnd: referenceDay,
            aggregation: .sum
        ) {
            dataset.dailyMetrics[.steps] = cue.metrics?.daily
            dataset.provenance[.steps] = provenance(for: stepValues, sampleType: "stepCount")
            var recentCue = cue
            if let metrics = cue.metrics {
                recentCue.metrics = .init(
                    periodStart: recentStart, periodEnd: referenceDay,
                    summaryValue: TrackingStatistics.median(Array(metrics.daily.suffix(7)).compactMap(\.value)),
                    unit: metrics.unit, sampleCount: stepValues.count, daily: Array(metrics.daily.suffix(7))
                )
            }
            cues.append(recentCue)
        }
        if let analysis = try? await analyzer.analyze(eventDate: referenceDate, availableData: dataset) {
            let sleepDetailMetrics: Set<TrackingMetric> = [.sleepTiming, .sleepWakeTime, .sleepContinuity]
            for insight in analysis.insights where sleepDetailMetrics.contains(insight.metric) {
                cues.append(TrackingCue(
                    source: .healthSleep,
                    observation: insight.neutralObservation,
                    metrics: nil,
                    insight: insight
                ))
            }
            for index in cues.indices where cues[index].insight == nil {
                let metric: TrackingMetric = switch cues[index].source {
                case .healthSleep: .sleepDuration
                case .healthHeartRate: .restingHeartRate
                case .healthHRV: .heartRateVariability
                case .healthSteps: .steps
                case .calendarLoad: .calendarLoad
                }
                if let insight = analysis.insights.first(where: { $0.metric == metric }) {
                    cues[index].insight = insight
                    cues[index] = TrackingCue(
                        id: cues[index].id,
                        source: cues[index].source,
                        observation: insight.neutralObservation,
                        included: false,
                        metrics: cues[index].metrics,
                        insight: insight
                    )
                }
            }
            if let sleepIndex = cues.firstIndex(where: { $0.source == .healthSleep && $0.metrics != nil }),
               let durationInsight = cues[sleepIndex].insight {
                let detailInsights = analysis.insights.filter { $0.metric.isSleepNightMetric }
                cues[sleepIndex] = TrackingCue(
                    id: cues[sleepIndex].id,
                    source: .healthSleep,
                    observation: sleepContextObservation(
                        durationInsight: durationInsight,
                        detailInsights: detailInsights
                    ),
                    metrics: cues[sleepIndex].metrics,
                    insight: durationInsight
                )
            }
        }
        return cues
    }

    private func samples(type: HKSampleType, start: Date, end: Date) async -> [HKSample] {
        await withCheckedContinuation { continuation in
            let predicate = HKQuery.predicateForSamples(withStart: start, end: end)
            let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, samples, _ in
                continuation.resume(returning: samples ?? [])
            }
            store.execute(query)
        }
    }

    private func quantityCue(
        source: TrackingSource,
        label: String,
        samples: [HKQuantitySample],
        unit: HKUnit,
        suffix: String,
        days: [Date],
        periodStart: Date,
        periodEnd: Date,
        aggregation: QuantityAggregation = .average
    ) -> TrackingCue? {
        let values = samples.map { $0.quantity.doubleValue(for: unit) }
        guard !values.isEmpty else { return nil }
        let average = TrackingStatistics.median(values)
        let calendar = Calendar.current
        let groups = Dictionary(grouping: samples) { calendar.startOfDay(for: $0.startDate) }
        let daily = days.map { day -> TrackingDataPoint in
            let samples = groups[day] ?? []
            let values = samples.map { $0.quantity.doubleValue(for: unit) }
            let dailyAverage: Double?
            if values.isEmpty {
                dailyAverage = nil
            } else {
                switch aggregation {
                case .average:
                    dailyAverage = TrackingStatistics.median(values)
                case .sum:
                    dailyAverage = values.reduce(0, +)
                }
            }
            return .init(date: day, value: dailyAverage, count: samples.count)
        }
        return .init(
            source: source,
            observation: "\(label)中有 \(daily.filter { $0.value != nil }.count) 天可用记录，记录本身不能说明原因。",
            metrics: .init(
                periodStart: periodStart,
                periodEnd: periodEnd,
                summaryValue: average,
                unit: suffix,
                sampleCount: values.count,
                daily: daily
            )
        )
    }

    private enum QuantityAggregation { case average, sum }

    /// Select one source deterministically before aggregation. The source with the most
    /// distinct recorded days wins; ties use sample count and bundle identifier. This prevents
    /// duplicate records from multiple devices from being silently added together.
    private func preferredSourceSamples<T: HKSample>(_ samples: [T]) -> [T] {
        let calendar = Calendar.current
        let groups = Dictionary(grouping: samples) { $0.sourceRevision.source.bundleIdentifier }
        let candidates = groups.map { bundle, values in
            TrackingSourceCandidate(
                bundleIdentifier: bundle,
                distinctDayCount: Set(values.map { calendar.startOfDay(for: $0.startDate) }).count,
                sampleCount: values.count
            )
        }
        guard let preferred = HealthSourcePriorityPolicy().preferredBundleIdentifier(from: candidates) else {
            return []
        }
        return groups[preferred] ?? []
    }

    private func provenance<T: HKSample>(for samples: [T], sampleType: String) -> [TrackingProvenance] {
        Dictionary(grouping: samples) { $0.sourceRevision.source.bundleIdentifier }
            .map { bundle, values in
                let first = values.first
                return TrackingProvenance(
                    sampleType: sampleType,
                    sourceName: first?.sourceRevision.source.name,
                    sourceBundleIdentifier: bundle,
                    sourceVersion: first?.sourceRevision.version,
                    deviceName: first?.device?.name,
                    startDate: values.map(\.startDate).min(),
                    endDate: values.map(\.endDate).max(),
                    timeZoneIdentifier: TimeZone.current.identifier,
                    sampleCount: values.count,
                    authorizationStatus: "read request completed; HealthKit does not disclose read denial per type"
                )
            }
            .sorted { ($0.sourceBundleIdentifier ?? "") < ($1.sourceBundleIdentifier ?? "") }
    }

    /// HealthKit can contain overlapping sleep records from multiple devices or
    /// sleep stages. Merge intervals so the visualized duration is not doubled.
    private func mergedDuration(of samples: [HKCategorySample]) -> TimeInterval {
        let intervals = samples
            .map { ($0.startDate, $0.endDate) }
            .sorted { $0.0 < $1.0 }
        guard var current = intervals.first else { return 0 }
        var total: TimeInterval = 0
        for interval in intervals.dropFirst() {
            if interval.0 <= current.1 {
                current.1 = max(current.1, interval.1)
            } else {
                total += current.1.timeIntervalSince(current.0)
                current = interval
            }
        }
        total += current.1.timeIntervalSince(current.0)
        return max(0, total)
    }

    private func sleepContextObservation(
        durationInsight: TrackingInsight,
        detailInsights: [TrackingInsight]
    ) -> String {
        let byMetric = Dictionary(uniqueKeysWithValues: detailInsights.map { ($0.metric, $0) })
        var parts: [String] = []
        if let duration = durationInsight.recentMedian {
            var item = "时长中位数约 \(String(format: "%.1f", duration)) 小时"
            if let difference = durationInsight.absoluteDifference {
                let minutes = Int((abs(difference) * 60).rounded())
                item += "（比个人近期水平约 \(minutes) 分钟\(difference >= 0 ? "更多" : "更少")"
            }
            parts.append(item)
        }
        if let onset = byMetric[.sleepTiming]?.recentMedian {
            var item = "入睡约 \(clockTime(onset))"
            if let difference = byMetric[.sleepTiming]?.absoluteDifference {
                item += "（约 \(Int((abs(difference) * 60).rounded())) 分钟\(difference >= 0 ? "更晚" : "更早")）"
            }
            parts.append(item)
        }
        if let wake = byMetric[.sleepWakeTime]?.recentMedian {
            var item = "醒来约 \(clockTime(wake))"
            if let difference = byMetric[.sleepWakeTime]?.absoluteDifference {
                item += "（约 \(Int((abs(difference) * 60).rounded())) 分钟\(difference >= 0 ? "更晚" : "更早")）"
            }
            parts.append(item)
        }
        if let continuity = byMetric[.sleepContinuity]?.recentMedian {
            var item = "已记录睡眠区间连续程度约 \(Int((continuity * 100).rounded()))%"
            if let difference = byMetric[.sleepContinuity]?.absoluteDifference {
                item += "（约 \(Int((abs(difference) * 100).rounded())) 个百分点\(difference >= 0 ? "更高" : "更低")）"
            }
            parts.append(item)
        }
        let coverage = durationInsight.coverageDescription
        let measurements = parts.isEmpty ? "记录不足以形成睡眠作息描述" : parts.joined(separator: "；")
        return "最近 \(coverage)：\(measurements)。这些记录共同描述作息和设备记录到的睡眠连续程度，不等同于主观睡眠质量，也不能说明情绪、原因或责任。"
    }

    private func clockTime(_ decimalHour: Double) -> String {
        let normalized = ((decimalHour.truncatingRemainder(dividingBy: 24)) + 24)
            .truncatingRemainder(dividingBy: 24)
        let minutes = Int((normalized * 60).rounded()) % (24 * 60)
        return String(format: "%02d:%02d", minutes / 60, minutes % 60)
    }
}

actor CalendarService {
    private let store = EKEventStore()
    private let analyzer = DeterministicSelfTrackingAnalyzer()
    func requestAuthorization() async { _ = try? await store.requestFullAccessToEvents() }

    func accessMessage() -> String {
        switch EKEventStore.authorizationStatus(for: .event) {
        case .fullAccess, .authorized: "日历已获得完整读取权限。"
        case .writeOnly: "日历目前只有写入权限，无法读取日程。"
        case .denied: "日历读取权限已被拒绝，请到系统设置中允许。"
        case .restricted: "该设备限制了日历读取。"
        case .notDetermined: "日历读取权限尚未确认。"
        @unknown default: "日历权限状态无法确认。"
        }
    }

    func fetch(referenceDate: Date) async -> [TrackingCue] {
        guard EKEventStore.authorizationStatus(for: .event) == .fullAccess else { return [] }
        let calendar = Calendar.current
        let referenceDay = calendar.startOfDay(for: referenceDate)
        let recentStart = calendar.date(byAdding: .day, value: -6, to: referenceDay) ?? referenceDay
        let start = calendar.date(byAdding: .day, value: -34, to: referenceDay) ?? recentStart
        let end = calendar.date(byAdding: .day, value: 1, to: referenceDay) ?? referenceDate
        let items = store.events(matching: store.predicateForEvents(withStart: start, end: end, calendars: nil))
        let historyDays = (0..<35).compactMap { calendar.date(byAdding: .day, value: $0, to: start) }
        let dailyHistory = historyDays.map { day -> TrackingDataPoint in
            let dayEnd = calendar.date(byAdding: .day, value: 1, to: day) ?? day
            let overlapping = items.filter { $0.startDate < dayEnd && $0.endDate > day }
            let timedHours = overlapping.filter { !$0.isAllDay }.reduce(0.0) { partial, event in
                let clippedStart = max(event.startDate, day)
                let clippedEnd = min(event.endDate, dayEnd)
                return partial + max(0, clippedEnd.timeIntervalSince(clippedStart)) / 3600
            }
            return .init(date: day, value: timedHours, count: overlapping.count)
        }
        let recentDaily = Array(dailyHistory.suffix(7))
        let recentItems = items.filter { $0.endDate > recentStart }
        let recentTimed = recentItems.filter { !$0.isAllDay }
        var cue = TrackingCue(
            source: .calendarLoad,
            observation: "最近 7 天中记录到 \(recentItems.count) 个日程；这里只统计占用时间，不读取标题或内容。",
            metrics: .init(
                periodStart: recentStart,
                periodEnd: referenceDay,
                summaryValue: TrackingStatistics.median(recentDaily.compactMap(\.value)),
                unit: "小时",
                sampleCount: recentTimed.count,
                daily: recentDaily
            )
        )
        let provenance = TrackingProvenance(
            sampleType: "calendarEvents",
            sourceName: "EventKit",
            sourceBundleIdentifier: nil,
            sourceVersion: nil,
            deviceName: nil,
            startDate: start,
            endDate: end,
            timeZoneIdentifier: TimeZone.current.identifier,
            sampleCount: items.count,
            authorizationStatus: accessMessage()
        )
        let dataset = SelfTrackingDataset(
            dailyMetrics: [.calendarLoad: dailyHistory],
            provenance: [.calendarLoad: [provenance]]
        )
        if let analysis = try? await analyzer.analyze(eventDate: referenceDate, availableData: dataset),
           let insight = analysis.insights.first {
            cue.insight = insight
            cue = TrackingCue(
                id: cue.id,
                source: .calendarLoad,
                observation: insight.neutralObservation,
                metrics: cue.metrics,
                insight: insight
            )
        }
        return [cue]
    }
}
